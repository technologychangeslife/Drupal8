(function ($) {
  /**
   * Products Search results creation.
   */
  Drupal.behaviors.search = {
    attach: function (context, settings) {
      const searchResults = $('.search-results');
      const additionalComp = $('.jfm-search-form .additional-components');
      const inputField = $('.jfm-search-form .search-product.form-text');
      inputField.val('');
      let langCode = null;
      if (settings && settings.path && settings.path.currentLanguage) {
        langCode = (settings.path.currentLanguage !== 'en') ? settings.path.currentLanguage : null;
      }

      inputField.once('search').each(function () {
        $(this).after('<span class="search-icon">icon</span>');
        $(this).on('input', function () {
          var searchStringoriginal = $(this).val();
          var searchString = searchStringoriginal.toLowerCase();
          searchResults.html('');
          additionalComp.show();
          // Search string not empty & minimum 3 characters.
          if (searchString && searchString.length > 2 ) {
            additionalComp.hide();
            let url = `/api/v1/products-search`;
            if (langCode) {
              url = `/${langCode}/api/v1/products-search`;
            }
            $.get(url, function (results) {
              var $rescounter = 0;
              var $result = '';
              $.each(results, function (resk, resv) {
                if (resv['title'].toLowerCase().indexOf(searchString) != -1 ||
                  resv['summary'].toLowerCase().indexOf(searchString) != -1 ||
                  resv['category'].toLowerCase().indexOf(searchString) != -1 ||
                  resv['shade'].toLowerCase().indexOf(searchString) != -1
                ) {
                  $result += '<li><a href="' + resv['url'] + '">' + resv['title'] + '</a>' +
                    '<span class="double-close">XX</span></li>';
                  $rescounter += 1;
                }
                if ($rescounter >= 5) {
                  return false;
                }
              });
              $result = '<ul>' + $result + '</ul>';
              if ($rescounter) {
                let searchResultsUrl = '/products-search?q=';
                if (langCode) {
                  searchResultsUrl = `/${langCode}${searchResultsUrl}`;
                }
                $result += '<div class="results-page"><a href="' + searchResultsUrl
                + searchStringoriginal + '">' + Drupal.t('View All Results') + '</a></div>';
              }
              searchResults.html($result);

              // Add event listner click for each double-close element.
              var doubleclose = document.querySelectorAll(".double-close");
              doubleclose.forEach(item => {
                item.addEventListener('click', removeElement)
              });
            });
          }
        });
      })

      // Function to remove the clicked element &
      // show search menu & trending products if no results are there.
      function removeElement() {
        $(this).parent().remove();
        if ($('.search-results li').length == 0) {
          searchResults.html('');
          additionalComp.show();
        }
      }

      // Click action for search icon.
      $('.jfm-search-form .search-icon').once('search-icon').click(function () {
        if (inputField.val().length > 2) {
          let searchResultsUrl = '/products-search?q=';
          if (langCode) {
            searchResultsUrl = `/${langCode}${searchResultsUrl}`;
          }
          window.location.replace(searchResultsUrl + inputField.val());
        }
      });

      // For Search Modal
      $(".search-modal").once().click(function (e) {
        e.stopPropagation();
        $('.products-submenu-block').slideUp();
        $(".user-profile").removeClass('opened');
        $('.jfm-search-form').toggleClass('open');
        inputField.focus();
        $('html').toggleClass('search-form-open');
        if (!$('.jfm-search-form').hasClass('open')) {
          inputField.val('');
          searchResults.html('');
        }
      });

      $(".jfm-search-form .close").once().click(function () {
        $('.jfm-search-form').removeClass('open');
        $('html').removeClass('search-form-open');
        inputField.val('');
        searchResults.html('');
        additionalComp.show();
      });

      $(document).click(function () {
        $('.jfm-search-form').removeClass('open');
        $('html').removeClass('search-form-open');
      });

       // Prevent events from getting pass .popup
      $('.jfm-search-form').click(function(e){
        e.stopPropagation();
      });

      inputField.keyup(function (ev) {
        if ($(this).val() == "Search") $(this).val("");
        // Enter Key when searched.
        if ((ev.key === 'Enter' || ev.keyCode === 13) && $(this).val().length > 2 ) {
          let searchResultsUrl = '/products-search?q=';
          if (langCode) {
            searchResultsUrl = `/${langCode}${searchResultsUrl}`;
          }
          window.location.replace(searchResultsUrl + $(this).val());
        }
      });

      // Adding referrer link.
      if ($('.search-modal-results').length) {
        $('.search-modal-results .referrer').attr('href', document.referrer);
      }
    }
  }
})(jQuery, Drupal);
