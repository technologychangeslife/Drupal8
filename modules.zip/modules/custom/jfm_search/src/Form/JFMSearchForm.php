<?php

namespace Drupal\jfm_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Search Form for product autocomplete search.
 */
class JFMSearchForm extends FormBase {

  use StringTranslationTrait;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'jfm_search_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['search_product'] = [
      '#type' => 'textfield',
      '#attributes' => [
        'placeholder' => $this->t('Search'),
        'class' => ['search-product'],
        'autocomplete' => 'off',
        'list' => 'autocompleteOff',
      ],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {}

}
