<?php

namespace Drupal\jfm_search\Plugin\Block;

use GuzzleHttp\ClientInterface;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'jfm_products_search_results' block.
 *
 * @Block(
 *   id = "jfm_products_search_results_block",
 *   admin_label = @Translation("JFM Products Search Results Block")
 * )
 */
class JFMProductsSearchResultsBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * A entityTypeManager variable.
   *
   * @var Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The HTTP client to fetch the feed data with.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected $httpClient;

  /**
   * File url generator object.
   *
   * @var \Drupal\Core\File\FileUrlGeneratorInterface
   */
  protected $fileUrlGenerator;

  /**
   * A Request stack variable.
   *
   * @var Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * A Node Storage variable.
   *
   * @var Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $nodeStorage;

  /**
   * The language manager service.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    ClientInterface $http_client,
    FileUrlGeneratorInterface $file_url_generator,
    RequestStack $request_stack,
    LanguageManagerInterface $language_manager
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->httpClient = $http_client;
    $this->fileUrlGenerator = $file_url_generator;
    $this->requestStack = $request_stack->getCurrentRequest();
    $this->nodeStorage = $entity_type_manager->getStorage('node');
    $this->languageManager = $language_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('http_client'),
      $container->get('file_url_generator'),
      $container->get('request_stack'),
      $container->get('language_manager'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $input = filter_var($this->requestStack->query->get('q'), FILTER_SANITIZE_STRING);
    $language = $this->languageManager->getCurrentLanguage(LanguageInterface::TYPE_CONTENT)->getId();
    $default_lang = $this->languageManager->getDefaultLanguage()->getId();
    $products_data = ($language !== $default_lang) ?
      $this->httpClient->get($this->requestStack->getHost() . '/' . $language . '/api/v1/products-search') :
      $this->httpClient->get($this->requestStack->getHost() . '/api/v1/products-search');
    $data = json_decode($products_data->getBody()->getContents(), TRUE);
    $nodes = $this->nodeStorage->loadByProperties(['type' => 'products']);

    // Get the typed string from the URL, if it exists.
    if ($input) {
      $nids = $this->getResults($data, strtolower($input));
      $nodes = $nids ? $this->nodeStorage->loadMultiple($nids) : [];
    }

    $items = [];
    foreach ($nodes as $node) {
      // Product image.
      $image = [];
      $translated_entity = $node->hasTranslation($language) ? $node->getTranslation($language) : NULL;
      if ($translated_entity) {
        $image['url'] = '';
        if ($translated_entity->field_product_image->entity) {
          $image_path = $translated_entity->field_product_image->entity->getFileUri();
          $image_style_manager = $this->entityTypeManager->getStorage('image_style')->load('product_list_card_images_scale_154_154');
          if ($image_style_manager && !empty($image_path)) {
            $image['url'] = $image_style_manager->buildUrl($image_path);
          }
          $image['alt'] = $translated_entity->field_product_image->alt ?? $this->t('Product image');
        }

        // Coverage icon in taxonomy.
        $icon_entity = $translated_entity->field_coverage->entity->field_icon->entity;
        $icon = '';
        if ($icon_entity) {
          $icon = $this->fileUrlGenerator->generateAbsoluteString($icon_entity->getFileUri());
        }

        $coverage = $time = '';
        if ($translated_entity->field_coverage->entity) {
          $coverage = $translated_entity->field_coverage->entity->getName();
        }

        if ($translated_entity->field_time_to_apply->entity) {
          $time = $translated_entity->field_time_to_apply->entity->getName();
        }

        $product_shade_count = 0;
        if ($translated_entity->hasField('field_product_shade') && !$translated_entity->get('field_product_shade')->isEmpty()) {
          $product_shade_count = count($translated_entity->get('field_product_shade')->getValue());
        }

        $disable_vto_experience = NULL;
        if ($translated_entity->hasField('field_disable_vto_experience') && !$translated_entity->get('field_disable_vto_experience')->isEmpty()) {
          $disable_vto_experience = $translated_entity->get('field_disable_vto_experience')->value;
        }

        // Preparing Data.
        $items[] = [
          'nid' => $translated_entity->id(),
          'url' => $translated_entity->toUrl()->toString(),
          'title' => $translated_entity->getTitle(),
          'coverage' => $coverage,
          'icon' => $icon,
          'shades' => $translated_entity->field_number_of_shades->value,
          'time' => $time,
          'image' => $image,
          'productShadeCount' => $product_shade_count,
          'disableVtoExperience' => $disable_vto_experience,
        ];
      }
    }

    return [
      '#theme' => 'products_search',
      '#items' => $items,
      '#searchtext' => $input,
      '#itemscount' => count($nodes),
      '#referer' => $this->requestStack->headers->get('referer'),
      '#markup' => $this->t('Products Search Results'),
      '#language' => $language,
      '#cache' => [
        'contexts' => ['url'],
      ],
    ];
  }

  /**
   * Get results function to get nids.
   */
  public function getResults(array $data, $input) {
    $nids = [];
    foreach ($data as $value) {
      if (str_contains(strtolower($value['title']), $input) ||
        str_contains(strtolower($value['summary']), $input) ||
        str_contains(strtolower($value['shade']), $input) ||
        str_contains(strtolower($value['category']), $input)
      ) {
        $nids[] = $value['nid'];
      }
    }

    return $nids;
  }

}
