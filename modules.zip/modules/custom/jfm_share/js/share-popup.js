(function ($, Drupal, once, _, Backbone) {
  Drupal.behaviors.sharepopup = {
    attach: function (context, settings) {
      $('.close-popup').click(function () {
        $(".popup").removeClass('is-open-popup');
        $('body').removeClass('is-popup');
      })
    },
  };
})(jQuery, Drupal, once);
