<?php

namespace Drupal\jfm_share\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\views\Views;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Routing\RouteMatchInterface;

/**
 * Provides a block called "JFM Social Share Block".
 *
 * @Block(
 *  id = "jfm_social_share_block",
 *  admin_label = @Translation("JFM Social Share Block")
 * )
 */
class SocialShareBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Drupal\Core\Entity\EntityTypeManagerInterface definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The renderer.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The current route match.
   *
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  protected $routeMatch;

  /**
   * Constructs a new CartBlock.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\Core\Routing\RouteMatchInterface $route_match
   *   The current route match.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    RendererInterface $renderer,
    RouteMatchInterface $route_match
    ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->renderer = $renderer;
    $this->routeMatch = $route_match;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('renderer'),
      $container->get('current_route_match'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $details = [];
    $nid = $this->routeMatch->getRawParameter('node');
    $nid = (int) $nid;
    if ($nid) {
      $details = $this->getProductDatils($nid);
    }

    return [
      '#theme' => 'share_block',
      '#share_info' => [
        'data' => ['design_type' => 'product', 'details' => $details],
      ],
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }

  /**
   * Function to get product details.
   *
   * @param int $nid
   *   Product id.
   *
   * @return array
   *   product data.
   */
  private function getProductDatils($nid) {
    if (empty($nid)) {
      return FALSE;
    }
    $data = [];
    $view = Views::getView('products');
    $render_array = $view->buildRenderable('rest_export_2', [$nid]);
    $rendered = $this->renderer->renderRoot($render_array);
    $json_string = $rendered->jsonSerialize();
    $product_decode = json_decode($json_string, TRUE);
    if (!empty($product_decode)) {
      $product = $product_decode[key($product_decode)];
      $data = [
        'title' => $product['title'],
        'number_of_reviews' => $product['field_number_of_reviews'],
        'ratings' => $product['field_ratings'],
        'image' => $product['field_product_image'],
        'product_url' => $product['view_node'],
        'coverage' => $product['field_coverage'],
        'time' => $product['field_time_to_apply'],
        'shades' => $product['field_number_of_shades'],
      ];
    }
    return $data;
  }

}
