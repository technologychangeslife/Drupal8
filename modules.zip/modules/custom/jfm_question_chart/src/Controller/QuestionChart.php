<?php

namespace Drupal\jfm_question_chart\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use GuzzleHttp\ClientInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Display a formatted tree type structure for question and answers as nodes.
 */
class QuestionChart extends ControllerBase {

  /**
   * A entityTypeManager variable.
   *
   * @var Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The HTTP client to fetch the feed data with.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected $httpClient;

  /**
   * The Current request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    ClientInterface $http_client,
    RequestStack $request_stack
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->httpClient = $http_client;
    $this->requestStack = $request_stack;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('http_client'),
      $container->get('request_stack')
    );
  }

  /**
   * Function passes a formatted array to the twig file for rendering.
   */
  public function content() {
    $hostUrl = $this->requestStack->getCurrentRequest()->getHost();
    $request = $this->httpClient->get($hostUrl . '/api/v1/productfinder');
    $data = json_decode($request->getBody()->getContents(), TRUE)['productFinderFields']['pfData'];

    return [
      '#theme' => 'question_chart',
      '#attached' => [
        'drupalSettings' => [
          'data' => $data,
          'final' => $this->processedData($data),
        ],
      ],
    ];
  }

  /**
   * Preparing data array with node ids.
   */
  public function processedData($data) {
    $final = [];
    foreach ($data as $value) {
      $final[$value['id']] = $value;
    }

    return $final;
  }

}
