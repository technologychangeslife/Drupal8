(function ($) {
  /**
   * Product Finder Question Chart.
   */
  Drupal.behaviors.QuestionChart = {
    attach: function (context, drupalSettings) {

      $('#chart_div').once('question').each(function () {
        google.charts.load('current', {packages:["orgchart"]});
        google.charts.setOnLoadCallback(drawChart);
      });

      var $root = [];
      var $apidata = drupalSettings.data;
      var $final = drupalSettings.final;
      var $description = '';
      var $response = [];
      var $rid = 0;

      // Function to generate org chart using google charts.
      function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', Drupal.t('Answer'));
        data.addColumn('string', Drupal.t('Question'));

        $.each($apidata, function (key, value) {
          var q1 = '<div style="border: 1px solid purple; color: purple;">' + Drupal.t('Question') + '</div>'
            + '<div style="color:red; font-style:italic">' + value['refID'] + ':'
            + value['title'] + '</div>';

          responseCreator($rid, q1);
          generate(value, $rid);
          return false;
        });

        // For each orgchart box, provide the Question, Answer to show.
        data.addRows($response);

        // Create the chart.
        var chart = new google.visualization.OrgChart(document.getElementById('chart_div'));
        // Draw the chart, setting the allowHtml option to true for the tooltips.
        chart.draw(data, {'allowHtml':true});
      }

      // Recursive function which generates the data for google chart.
      function generate($value, $respid = 0) {
        if ($value) {
          var parentid = $respid;
          // Processing through each answer to genrate child nodes.
          $.each($value['answers'], function (aid, avalue) {
            $description = avalue['title'] + getBorderBox(avalue);
            if (avalue['type'] == "Next Question" && $final[avalue['nextLink']]) {
              $description += '<div style="color:red; font-style:italic">' + $final[avalue['nextLink']]['refId'] + ': '
                + $final[avalue['nextLink']]['title'] + '</div>';
            }
            responseCreator($rid, $description, parentid - 1);
            generate($final[avalue['nextLink']], $rid);
          });
        }
      }

      // Response creator function.
      function responseCreator($child = 0, $description, $parent = '') {
        $root = [];
        $root[0] = [];
        $root[0] = {
          v: $child.toString(),
          f: $description,
        };
        $root[1] = $parent.toString();
        $response[$rid] = $root;
        $rid = $rid + 1;
      }

      // Border box function for styling.
      function getBorderBox($ansd) {
        var $border_box = '';
        if ($ansd["type"] == 'Next Question') {
          $border_box = '<div style="border: 1px solid purple; color: purple;">' + Drupal.t('Question') + '</div>';
        }
        else if ($ansd["type"] == 'Product Link') {
          $border_box = '<div style="border: 1px solid blue; color: blue;">' + Drupal.t('Product Link') + '</div>';
        }
        else if ($ansd["type"] == 'Category Link') {
          $border_box = '<div style="border: 1px solid green; color: green;">' + Drupal.t('Category Link') + '</div>';
        }
        else if ($ansd["type"] == 'Shade Selector') {
          $border_box = '<div style="border: 1px solid brown; color: brown;">' + Drupal.t('Shade Selector') + '</div>';
        }

        return $border_box;
      }
    }
  }
})(jQuery);
