## About

This module implements the backend part of Product Finder.
This module generates the product finder question graph.
