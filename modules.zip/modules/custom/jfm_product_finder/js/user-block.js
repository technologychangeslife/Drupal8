(function ($) {
  /**
   * User block name replacement.
   */
  Drupal.behaviors.user_block = {
    attach: function (context, settings) {
      $name = localStorage.getItem('productFinderUser');
      if ($name) {
        $('.product-finder-user-block .user-name').text($name);
      }
    }
  }
})(jQuery);
