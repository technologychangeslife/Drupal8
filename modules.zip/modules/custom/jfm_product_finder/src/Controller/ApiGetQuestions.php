<?php

namespace Drupal\jfm_product_finder\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManagerInterface;

/**
 * Implementing the JSON api.
 */
class ApiGetQuestions extends ControllerBase {

  /**
   * A entityTypeManager variable.
   *
   * @var Drupal\Core\Entity\EntityTypeManagerInterface
   */

  protected $entityTypeManager;

  /**
   * The language manager service.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, LanguageManagerInterface $language_manager) {
    $this->entityTypeManager = $entity_type_manager;
    $this->languageManager = $language_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('language_manager'),
    );
  }

  /**
   * Callback for the API.
   */
  public function renderApi() {
    return new JsonResponse([
      'productFinderFields' => $this->getResults(),
    ]);
  }

  /**
   * A helper function returning results.
   */
  public function getResults() {

    $nodes = $this->entityTypeManager->getStorage('node')->loadByProperties(['type' => 'question']);

    $pf_data = $category = [];

    $response["pfName"] = NULL;
    // Add field names of more answer fields.
    $answer_fields = ['field_answer_1', 'field_answer_2', 'field_answer_3'];

    $language = $this->languageManager->getCurrentLanguage(LanguageInterface::TYPE_CONTENT)->getId();
    foreach ($nodes as $node) {
      $resp = $answers = [];
      $translation = $node->hasTranslation($language);
      if ($translation) {
        $node = $node->getTranslation($language);
        $resp["id"] = (int) $node->nid->value;
        $resp["category"] = $category[$resp["id"]] ?? NULL;
        $resp["refId"] = $node->title->value;
        $resp["title"] = $node->field_question->value;
        $resp["beforeContent"] = strip_tags($node->field_before_content->value);

        // Loop to get answer data.
        foreach ($answer_fields as $id => $fieldname) {
          $paragraph = $node->get($fieldname)->referencedEntities();
          if (!$paragraph || !$paragraph[0]->field_answer_title->value) {
            continue;
          }

          $answers[$id]['id'] = (int) $paragraph[0]->id->value;
          $answers[$id]["title"] = $paragraph[0]->field_answer_title->value;
          $answers[$id]["refId"] = $paragraph[0]->field_answer_ref_id->value;
          $answers[$id]["type"] = $paragraph[0]->field_answer_type->value;
          $answers[$id]["nextLink"] = NULL;
          $image_url = "";
          if ($paragraph[0]->field_image->getValue()) {
            $uri = $paragraph[0]->field_image->entity->getFileUri();
            $image_url = file_create_url($uri);
          }
          $answers[$id]["icon"] = $image_url;

          // Category value store.
          if ($resp["category"] && !is_null($answers[$id]["nextLink"])) {
            $category[$answers[$id]["nextLink"]] = $resp["category"];
          }
          elseif (!is_null($answers[$id]["nextLink"])) {
            $category[$answers[$id]["nextLink"]] = $answers[$id]["title"];
          }

          $answers[$id]["nextLink"] = $this->getNextSelection($answers[$id], $paragraph);

        }

        $resp["answers"] = $answers;
        $resp["selectedAns"] = $resp["lsType"] = $resp["show"] = $resp["level"] = NULL;

        $pf_data[] = $resp;
      }

    }

    $response["hasData"] = $pf_data ? TRUE : FALSE;
    $response["pfData"] = $pf_data;

    return $response;
  }

  /**
   * Get Next Questions.
   */
  public function getNextSelection($answers, $paragraph) {
    $res_id = NULL;
    switch ($answers['type']) {
      case 'Product Link':
        $res_id = isset($paragraph[0]->field_product->getValue()[0]["target_id"]) ? (int) $paragraph[0]->field_product->getValue()[0]["target_id"] : NULL;
        break;

      case 'Next Question':
        $res_id = isset($paragraph[0]->field_next_question->getValue()[0]["target_id"]) ? (int) $paragraph[0]->field_next_question->getValue()[0]["target_id"] : NULL;
        break;

      case 'Shade Selector':
        $res_id = isset($paragraph[0]->field_shade->getValue()[0]["target_id"]) ? (int) $paragraph[0]->field_shade->getValue()[0]["target_id"] : NULL;
        break;

      case 'Category Link':
        $res_id = $res = isset($paragraph[0]->field_category->getValue()[0]["target_id"]) ? (int) $paragraph[0]->field_category->getValue()[0]["target_id"] : NULL;
        break;
    }
    return $res_id;
  }

}
