<?php

namespace Drupal\jfm_product_finder\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManagerInterface;

/**
 * Provides a block called "JFM Product Finder Bottom Block".
 *
 * @Block(
 *  id = "jfm_pf_bottom_block",
 *  admin_label = @Translation("JFM Products Finder Bottom Block")
 * )
 */
class JFMProductFinderRetakeBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The current route match.
   *
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  protected $routeMatch;

  /**
   * The language manager service.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition,
   RouteMatchInterface $route_match,
   LanguageManagerInterface $language_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->routeMatch = $route_match;
    $this->languageManager = $language_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_route_match'),
      $container->get('language_manager'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $form['top_link'] = [
      '#type' => 'details',
      '#title' => $this->t('Top Link'),
      '#open' => TRUE,
    ];

    $form['top_link']['top_link_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Top Link Title'),
      '#default_value' => $this->configuration['top_link_title'] ?? $this->t('Re-take product selector?'),
      '#required' => TRUE,
      '#maxlength' => 255,
      '#size' => 64,
    ];

    $form['top_link']['top_link_url'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Top link URL'),
      '#default_value' => $this->configuration['top_link_url'],
      '#maxlength' => 2048,
    ];

    $form['left'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Block Left'),
      '#default_value' => $this->configuration['left'] ?? $this->t('Want to know more about this product?'),
      '#required' => TRUE,
      '#maxlength' => 255,
      '#size' => 64,
    ];

    $form['right'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Block Right'),
      '#default_value' => $this->configuration['right'] ?? $this->t('Learn More'),
      '#required' => TRUE,
      '#maxlength' => 255,
      '#size' => 64,
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['top_link_title'] = $form_state->getValue([
      'top_link', 'top_link_title',
    ]);
    $this->configuration['top_link_url'] = $form_state->getValue([
      'top_link', 'top_link_url',
    ]);
    $this->configuration['left'] = $form_state->getValue('left');
    $this->configuration['right'] = $form_state->getValue('right');
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $node = $this->routeMatch->getParameter('node');
    $language_code = $this->languageManager->getCurrentLanguage(LanguageInterface::TYPE_CONTENT)->getId();
    $language = isset($language_code) ? $this->languageManager->getLanguage($language_code) : '';
    if ($node && $node->bundle() == 'products') {
      $options = ['absolute' => TRUE];
      if ($language_code != 'en') {
        $options += ['language' => $language];
      }
      $url = Url::fromRoute('entity.node.canonical', ['node' => $node->id()], $options);
      $url = $url->toString();
    }
    else {
      $language_code = $language_code != 'en' ? $language_code : '';
      $url = '/' . $language_code;
    }

    $top_link_url = $this->getConfiguration()['top_link_url'];
    $top_link_url = (isset($top_link_url) && $language_code != 'en') ? '/'. $language_code . $top_link_url : $top_link_url;
    return [
      '#linktitle' => $this->t('@title', ['@title' => $this->getConfiguration()['top_link_title']]),
      '#linkurl' => $top_link_url,
      '#left' => $this->t('@left', ['@left' => $this->getConfiguration()['left']]),
      '#right' => $this->t('@right', ['@right' => $this->getConfiguration()['right']]),
      '#rightlink' => $url,
      '#theme' => 'retake_block',
      '#markup' => $this->t('Retake Block'),
      '#cache' => [
        'contexts' => ['url'],
      ],
    ];
  }

}
