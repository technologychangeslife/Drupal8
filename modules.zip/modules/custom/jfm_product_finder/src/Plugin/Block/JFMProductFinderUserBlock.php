<?php

namespace Drupal\jfm_product_finder\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Provides a block called "JFM Product Finder Top Block".
 *
 * @Block(
 *  id = "jfm_pf_top_block",
 *  admin_label = @Translation("JFM Products Finder Top Block")
 * )
 */
class JFMProductFinderUserBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The current route match.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, RequestStack $request_stack) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->requestStack = $request_stack->getCurrentRequest();
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('request_stack')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#theme' => 'user_block',
      '#referer' => $this->requestStack->headers->get('referer'),
      '#markup' => $this->t('User Block'),
      '#attached' => [
        'library' => 'jfm_product_finder/user_block',
      ],
      '#cache' => [
        'contexts' => ['url'],
      ],
    ];
  }

}
