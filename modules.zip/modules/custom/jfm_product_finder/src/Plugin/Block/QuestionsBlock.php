<?php

namespace Drupal\jfm_product_finder\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block called "JFM Product Finder Questions Block".
 *
 * @Block(
 *  id = "jfm_pf_questions_block",
 *  admin_label = @Translation("JFM Products Finder Questions Block")
 * )
 */
class QuestionsBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('
      <div class="button" id="prev-question"><a href="#">Prev</a></div>
      <div id="product-finder-questions"></div>'),
    ];
  }

}
