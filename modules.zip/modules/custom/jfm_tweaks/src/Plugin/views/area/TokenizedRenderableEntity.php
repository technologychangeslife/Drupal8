<?php

namespace Drupal\jfm_tweaks\Plugin\views\area;

use Drupal\views\Plugin\views\area\Entity;

/**
 * Provides an area handler which renders an entity in a certain view mode.
 *
 * @ingroup views_area_handlers
 *
 * @ViewsArea("tokenized_renderable_entity")
 */
class TokenizedRenderableEntity extends Entity {

  /**
   * {@inheritdoc}
   */
  public function render($empty = FALSE) {
    if (!$empty || !empty($this->options['empty'])) {
      // @todo Use a method to check for tokens in
      //   https://www.drupal.org/node/2396607.
      if (strpos($this->options['target'], '{{') !== FALSE || strpos($this->options['target'], '[') !== FALSE) {
        // We cast as we need the integer/string value provided by the
        // ::tokenizeValue() call.
        $target_id = (string) $this->tokenizeValue($this->options['target']);
        if ($entity = $this->entityTypeManager->getStorage($this->entityType)->load($target_id)) {
          $target_entity = $entity;
        }
      }
      else {
        if ($entity = $this->entityRepository->loadEntityByConfigTarget($this->entityType, $this->options['target'])) {
          $target_entity = $entity;
        }
      }
      if (isset($target_entity) && (!empty($this->options['bypass_access']) || $target_entity->access('view'))) {
        $view_builder = $this->entityTypeManager->getViewBuilder($this->entityType);
        return $view_builder->view($target_entity, $this->options['view_mode']);
      }
    }

    return [];
  }

}
