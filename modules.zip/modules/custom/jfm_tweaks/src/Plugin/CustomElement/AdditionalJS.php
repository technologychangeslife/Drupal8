<?php

namespace Drupal\jfm_tweaks\Plugin\CustomElement;

use Drupal\cohesion_elements\CustomElementPluginBase;

/**
 * Element to attach custom libraries.
 *
 * @package Drupal\cohesion\Plugin\CustomElement
 *
 * @CustomElement(
 *   id = "additional_js",
 *   label = @Translation("Additional JS Controller")
 * )
 */
class AdditionalJS extends CustomElementPluginBase {

  /**
   * {@inheritdoc}
   */
  public function getFields() {
    return [
      'library' => [
        'type' => 'textfield',
        'placeholder' => 'my-project/my-library',
        'title' => 'Library',
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function render($element_settings, $element_markup, $element_class, $element_context = []) {
    $build['#attached']['library'][] = $element_settings['library'];
    return $build;
  }

}
