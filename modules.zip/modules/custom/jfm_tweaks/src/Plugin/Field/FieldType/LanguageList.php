<?php

namespace Drupal\jfm_tweaks\Plugin\Field\FieldType;

use Drupal\Core\TypedData\DataDefinition;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Field\FieldItemBase;

/**
 * Field type "language_list".
 *
 * @FieldType(
 *   id = "language_list",
 *   label = @Translation("Language List"),
 *   description = @Translation("Custom Language field."),
 *   category = @Translation("Language List"),
 *   default_widget = "language_list_default",
 *   default_formatter = "language_list_default",
 * )
 */
class LanguageList extends FieldItemBase {

  /**
   * {@inheritdoc}
   */
  public static function schema(FieldStorageDefinitionInterface $field_definition) {

    return [
      'columns' => [
        'language_list' => [
          'type' => 'varchar',
          'description' => t('Language List'),
          'not null' => FALSE,
          'length' => 10,
        ],
      ],
      'indexes' => [
        'value' => ['language_list'],
      ],
    ];

  }

  /**
   * {@inheritdoc}
   */
  public function isEmpty() {
    $value = $this->get('language_list')->getValue();
    return $value === NULL || $value === '';
  }

  /**
   * {@inheritdoc}
   */
  public static function propertyDefinitions(FieldStorageDefinitionInterface $field_definition) {

    $properties['language_list'] = DataDefinition::create('string')
      ->setLabel(t('language List'));

    return $properties;
  }

}
