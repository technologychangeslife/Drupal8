<?php

namespace Drupal\jfm_tweaks\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Field formatter "language_list_default".
 *
 * @FieldFormatter(
 *   id = "language_list_default",
 *   label = @Translation("Language List default"),
 *   field_types = {
 *     "language_list",
 *   }
 * )
 */
class LanguageListDefaultFormatter extends FormatterBase {

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {

    $output = [];

    foreach ($items as $delta => $item) {

      $build = [];

      $build['language_list'] = [
        '#type' => 'container',
        '#attributes' => [
          'class' => ['language__options'],
        ],
        'label' => [
          '#type' => 'container',
          '#attributes' => [
            'class' => ['field__label'],
          ],
          '#markup' => $this->t('Language List'),
        ],
        'value' => [
          '#type' => 'container',
          '#attributes' => [
            'class' => ['field__item'],
          ],
          // We use #plain_text instead of #markup to prevent XSS.
          // plain_text will clean up the language list and render an
          // HTML entity encoded string to prevent bad-guys from
          // injecting JavaScript.
          '#plain_text' => $item->modes,
        ],
      ];

      $output[$delta] = $build;
    }
    return $output;
  }

}
