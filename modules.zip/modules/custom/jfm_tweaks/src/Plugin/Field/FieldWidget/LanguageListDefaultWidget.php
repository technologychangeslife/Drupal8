<?php

namespace Drupal\jfm_tweaks\Plugin\Field\FieldWidget;

use Drupal\Core\Field\WidgetBase;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;

/**
 * Field widget "donation_default".
 *
 * @FieldWidget(
 *   id = "language_list_default",
 *   label = @Translation("Language List default"),
 *   field_types = {
 *     "language_list",
 *   }
 * )
 */
class LanguageListDefaultWidget extends WidgetBase implements ContainerFactoryPluginInterface {
  /**
   * The language manager service.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * {@inheritdoc}
   */
  public function __construct($plugin_id, $plugin_definition, FieldDefinitionInterface $field_definition, array $settings, array $third_party_settings, LanguageManagerInterface $language_manager) {
    parent::__construct($plugin_id, $plugin_definition, $field_definition, $settings, $third_party_settings);
    $this->languageManager = $language_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static($plugin_id, $plugin_definition, $configuration['field_definition'], $configuration['settings'], $configuration['third_party_settings'], $container
      ->get('language_manager'));
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {

    $language_list = $this->getOptions();

    $element += [
      '#type' => 'fieldset',
    ];

    // Language List.
    $element['language_list'] = [
      '#title' => $this->t('Languages'),
      '#type' => 'select',
      '#options' => $language_list,
      '#empty_value' => '',
      '#default_value' => NULL ?? $items[$delta]->language_list,
      '#description' => $this->t('Select Languages'),
    ];

    return $element;

  }

  /**
   * Get country list.
   */
  protected function getOptions() {
    $options = [];
    $languages = $this->languageManager->getLanguages();
    foreach ($languages as $lang) {
      $options[$lang->getId()] = ucfirst($lang->getName());
    }
    return $options;

  }

}
