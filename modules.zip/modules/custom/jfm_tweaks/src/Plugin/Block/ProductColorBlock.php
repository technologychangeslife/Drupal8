<?php

namespace Drupal\jfm_tweaks\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\jfm_tweaks\JfmServices;
use Drupal\Core\Routing\CurrentRouteMatch;

/**
 * Provides a block called "JFM Products Color Block".
 *
 * @Block(
 *  id = "jfm_products_color_block",
 *  admin_label = @Translation("JFM Products Color Block")
 * )
 */
class ProductColorBlock extends BlockBase implements ContainerFactoryPluginInterface {


  /**
   * JfmService.
   *
   * @var Drupal\jfm_tweaks\JfmServices
   */
  protected $jfmService;

  /**
   * Route match object.
   *
   * @var Drupal\Core\Routing\CurrentRouteMatch
   */
  protected $routeMatch;

  /**
   * Creates an instance of the plugin.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container to pull out services used in the plugin.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   *
   * @return static
   *   Returns an instance of this plugin.
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
        $configuration,
        $plugin_id,
        $plugin_definition,
        $container->get('jfm_tweaks.jfm_services'),
        $container->get('current_route_match')
    );
  }

  /**
   * Constructs the Product Color Block.
   *
   * @param array $configuration
   *   The plugin configuration, i.e. an array with configuration values keyed
   *   by configuration option name. The special key 'context' may be used to
   *   initialize the defined contexts by setting it to an array of context
   *   values keyed by context names.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param Drupal\jfm_tweaks\JfmServices $jfmService
   *   Jfm service.
   * @param Drupal\Core\Routing\CurrentRouteMatch $route_match
   *   Route match.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, JfmServices $jfmService, CurrentRouteMatch $route_match) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->jmfService = $jfmService;
    $this->routeMatch = $route_match;
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $route_match = $this->routeMatch;
    $color = '';

    if ($route_match->getRouteName() == 'entity.node.canonical') {
      $node = $route_match->getParameter('node');
      $nid = $node->id();
      $color = $this->jmfService->getProductColor($nid);
    }
    return [
      '#theme' => 'jfm-product-color',
      '#product_color' => $color,
    ];
  }

}
