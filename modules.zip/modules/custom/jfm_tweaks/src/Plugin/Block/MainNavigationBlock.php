<?php

namespace Drupal\jfm_tweaks\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block called "Example hero block".
 *
 * @Block(
 *  id = "jfm_main_navigation_menu_block",
 *  admin_label = @Translation("JFM MainNavigation Menu Block")
 * )
 */
class MainNavigationBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('<div></div>'),
    ];
  }

}
