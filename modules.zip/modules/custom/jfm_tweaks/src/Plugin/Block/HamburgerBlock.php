<?php

namespace Drupal\jfm_tweaks\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block called "Example hero block".
 *
 * @Block(
 *  id = "jfm_hamburger_menu_block",
 *  admin_label = @Translation("JFM Hamburger Menu Block")
 * )
 */
class HamburgerBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('<div></div>'),
    ];
  }

}
