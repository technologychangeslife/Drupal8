<?php

namespace Drupal\jfm_tweaks\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block called "JFM Products Block".
 *
 * @Block(
 *  id = "jfm_products_block",
 *  admin_label = @Translation("JFM Products Block")
 * )
 */
class ProductBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('<div class="product-jfm"></div>'),
    ];
  }

}
