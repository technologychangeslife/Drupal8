<?php

namespace Drupal\jfm_tweaks\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block called "Product Variant Block".
 *
 * @Block(
 *  id = "jfm_product_variant",
 *  admin_label = @Translation("Block for Product Variant")
 * )
 */
class ProductVariantBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('<div class="jfm-product-variant"></div>'),
    ];
  }

}
