<?php

namespace Drupal\jfm_tweaks;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Class DefaultService.
 */
class JfmTwigExtension extends \Twig_Extension {

  /**
   * Database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $dbConnection;

  /**
   * Class constructor.
   */
  public function __construct(Connection $connection, EntityTypeManagerInterface $entity) {

    $this->dbConnection = $connection;
    $this->userStorage = $entity->getStorage('taxonomy_term');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
     $container->get('connection'),
     $container->get('entity_type.manager')
    );
  }

  /**
   * This function must return the unique extension name.
   */
  public function getName() {
    return 'jfm_twig_extensions';
  }

  /**
   * Function to declare extension functions.
   */
  public function getFunctions() {
    return [
      new \Twig_SimpleFunction('getLanguage',
        [$this, 'getLanguage'],
        ['is_safe' => ['html']]
      ),
    ];
  }

  /**
   * Twig extension function.
   */
  public function getLanguage($tid) {
    $query = $this->dbConnection->select('taxonomy_term_revision__field_language', 'lang');
    $data = $query
      ->fields('lang', ['field_language_language_list'])
      ->condition('lang.entity_id', $tid)
      ->execute()->fetchObject();
    $language = $data->field_language_language_list;

    return $language;
  }

}
