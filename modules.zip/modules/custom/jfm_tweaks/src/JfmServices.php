<?php

namespace Drupal\jfm_tweaks;

use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Class to create just for men common service.
 */
class JfmServices {

  /**
   * Database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $dbConnection;

  /**
   * {@inheritdoc}
   */
  protected $entity;

  /**
   * Class constructor.
   */
  public function __construct(Connection $connection, EntityTypeManagerInterface $entity) {

    $this->dbConnection = $connection;
    $this->termStorage = $entity->getStorage('taxonomy_term');
    $this->nodeStorage = $entity->getStorage('node');

  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
     $container->get('connection'),
     $container->get('entity_type.manager')
    );
  }

  /**
   * Get product color.
   */
  public function getProductColor($node_id) {
    $color = '';
    $node = $this->nodeStorage->load($node_id);
    if ($node->hasField('field_product_category') && !$node->get('field_product_category')->isEmpty()) {
      $category_id = $node->get('field_product_category')->target_id;
      $term = $this->termStorage->load($category_id);
      $color = $term->get('field_product_color')->value;
    }
    return $color;
  }

  /**
   * Get product categories having associated how to use video.
   */
  public function getProductCategoryWithValidVideo($language) {
    $query = $this->dbConnection->select('node__field_product_category', 'target');
    $query->join('node__field_how_to_use', 'nfd', 'target.entity_id = nfd.entity_id');
    $query->join('paragraph__field_how_to_use_mode', 'pfd', 'pfd.entity_id = nfd.field_how_to_use_target_id AND pfd.field_how_to_use_mode_value = :value', [':value' => 'video']);
    $query->condition('target.bundle', 'products', '=');
    $query->condition('target.deleted', 0);
    $query->condition('target.langcode', $language);
    $query->fields('target', ['field_product_category_target_id']);
    $terms = [];
    $rows = $query->distinct()->execute()->fetchAll();
    foreach ($rows as $row) {
      $terms[] = $row->field_product_category_target_id;
    }
    return $terms;
  }

}
