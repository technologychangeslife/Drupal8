(function ($) {

  Drupal.behaviors.productForm = {
    attach: function (context, settings) {
      // Testimonials conditional fields.
      $("#edit-group-testimonials .field--name-field-product-category, #edit-group-testimonials .field--name-field-testimonial-subtext").hide();
      var testimonialMode = $("#edit-field-testimonial-mode").val();

      $.testimonialFields = function (mode) {
        if (mode == "image") {
          $(
            "#edit-group-testimonials .field--name-field-images, #edit-group-testimonials .field--name-field-testimonial-title, #edit-group-testimonials .field--name-field-testimonial-subtext"
          ).show();
        }
        if (mode == "text") {
          $(
            "#edit-group-testimonials .field--name-field-images, #edit-group-testimonials .field--name-field-testimonial-title, #edit-group-testimonials .field--name-field-testimonial-subtext"
          ).hide();
        }
        if (mode == "title") {
          $("#edit-group-testimonials .field--name-field-images, #edit-group-testimonials .field--name-field-testimonial-subtext").hide();
          $("#edit-group-testimonials .field--name-field-testimonial-title").show();
        }
      };
      $.testimonialFields(testimonialMode);

      $("#edit-field-testimonial-mode").change(function () {
        $.testimonialFields($(this).val());
      });
      $('.field--name-field-testimonial-text .form-textarea-wrapper textarea').css('height', 100);
    },
  };
})(jQuery);
