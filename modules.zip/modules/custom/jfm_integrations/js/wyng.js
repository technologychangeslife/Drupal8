/**
 * Wyng Integration.
 */

 (function ($, Drupal, drupalSettings, cookies) {
  Drupal.behaviors.jfm_integrations_wyng = {
    attach: function (context, drupalSettings) {
      "use strict";

      $('html', context).once('wyng').each(function () {
        // Check uid & wyng_login cookie is present or not.
        if (cookies.get('wyng-login')) {
          const accessToken = drupalSettings.wyng.access_token;
          window.wyng.profiles.init(accessToken);
          var wyng_login = cookies.get('wyng-login').split(',');
          //pushing email is not already exists.
          window.wyng.profiles.identify({
            email : wyng_login[2].toString()
          });
          // Send data to wyng.
          window.wyng.profiles.set({
            first_name: wyng_login[0].toString(),
            last_name: wyng_login[1].toString(),
          })
          .then((result) => {
            cookies.remove('wyng-login', { path: '/user', domain: window.location.hostname});
          })
          .catch((error) => {

          });
        }
      });
    }
  }
})(jQuery, Drupal, drupalSettings, window.Cookies);
