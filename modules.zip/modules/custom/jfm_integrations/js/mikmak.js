/**
 * Mikmak Integration.
 */

(function ($, Drupal) {
  Drupal.behaviors.jfm_integrations_mikmak = {
    attach: function (context, drupalSettings) {
      'use strict';

      $('html', context).once('mikmak').each(function () {

        let apiKey = drupalSettings.mikMakData.config.apikey;
        let apiEndpoint = drupalSettings.mikMakData.config.apiEndpoint;

        !function (e,t,i,r,a,d) {
          e[r] = e[r]||!1;
          var n = t.querySelectorAll(a);
          if(n) {
            for(var c = 0; c < n.length; c++){
              n[c].addEventListener("click",function (evt) {e[r] = evt})
            }
          }
          var m = t.createElement("script");
          m.setAttribute("data-mikmak-brand",i),
          m.type = "text/javascript",
          m.src = d,
          m.defer = !0,
          t.body.appendChild(m)
        }(
          window,
          document,
          apiKey,
          "mikmak_discover",
          ".mikmak-discover",
          apiEndpoint
        );

      });
    }
  }
})(jQuery, Drupal, drupalSettings);
