/**
 * Virtual Try On Integration.
 */

(function ($, Drupal) {
  Drupal.behaviors.jfm_integrations_vto = {
    attach: function (context, drupalSettings) {
      "use strict";

      $("html", context)
        .once("jfm_integrations_vto")
        .each(function () {

          const desktopScreen = 912; // Min desktop scren.
          const mobileScreen = 564; // Mgax mobile screen

          const langCode = drupalSettings.path.currentLanguage;

          // User is coming from homepage
          let productCat = initHandler();
          const nodeId = drupalSettings.vtoData.productId;
          initSdk(productCat);
          productTabOperations(productCat);
          cancelBuyingSelectedOption();
          buyingOptionAction();
          if(nodeId != 0 ) {
            initShadesLoad(nodeId);
            moveProduct(nodeId);
          }
          setReferrer();

          // Init VTO.
          function initSdk(productCategory = null) {
            let screenSize = getFrameSize();
            let featureType = null;

            if (productCategory == "head_hair") {
              featureType = 'hairdye';
            }
            else {
              featureType = 'bearddye';
            }

            if (featureType !== null && drupalSettings.vtoData.config.vto_apiEndpoint !== undefined) {
              (function (d, k) {
                var s = d.createElement("script");
                s.type = "text/javascript";
                s.async = true;
                s.featuretype = featureType;
                s.src = drupalSettings.vtoData.config.vto_apiEndpoint;
                var x = d.getElementsByTagName("script")[0];
                x.parentNode.insertBefore(s, x);
              })(document);

              window.ymkAsyncInit = function () {
                YMK.open();
                window.YMK.init({
                  autoOpen: true,
                  language: "enu",
                  showCompareCaption: true,
                  height: screenSize.frameHeight,
                  width: screenSize.frameWidth,
                  featuretype: featureType
                });

                window.YMK.addEventListener("loaded", function () {
                  YMK.enableCompare();
                });
              };
            }

            // Apply padding top/bottom on VTO frame.
            $('.btn-operations').css({
              'padding-top' : screenSize.framePadding + 'px',
              'padding-bottom' : screenSize.framePadding + 'px'
            });

          }

          // Init Handler.
          function initHandler() {
            let productCat = null;
            const nodeId = drupalSettings.vtoData.productId;
            const params = new URLSearchParams(window.location.search);
            let query_param = params.get('productCat');
            if (productCat == null && nodeId == 0 && query_param == null) {
              productCat = $(".vto-product-listing").find(".product-list:first").find(".product-listing__card-item:first").attr('data-attr');
            }
            else if (query_param != null) {
              productCat = query_param;
            }
            else {
              productCat = drupalSettings.vtoData.productCategory;
            }
            return productCat;
          }

          // Calculate height and width for VTO container.
          function getFrameSize() {
            let screenWidth = $(window).width();
            let screenHeight = $(window).height();
            let width = 360, height = 480;
            let maxHeight = 709;
            let maxWidth = 607;

            if (screenWidth > desktopScreen) {
              width = maxWidth;

              if (screenHeight > (maxHeight + 100)) {
                height = screenHeight - (screenHeight - maxHeight);
              }
              else {
                height = screenHeight - 100;
              }
            }
            else if ((screenWidth < desktopScreen) && (screenWidth > mobileScreen)) {
              height = screenHeight/50;
              width = screenWidth;
            }
            else if (screenWidth < mobileScreen) {
              height = 465;
              width = screenWidth;
            }

            let framePadding = 0;
            if (screenWidth > desktopScreen) {
              framePadding = screenHeight - height;
              if ($('body').hasClass('toolbar-horizontal')) {
                framePadding = framePadding - 80;
              }
              framePadding = framePadding/2;
            }

            return {
              screenHeight: screenHeight,
              screenWidth: screenWidth,
              frameHeight: (height > maxHeight) ? maxHeight : height,
              frameWidth: (width > maxWidth) ? maxWidth : width,
              framePadding: framePadding
            };
          }

          // Click event to get data-attr of product.
          const tabClickHandler = $(".product-list__tabs .product-list__tab");
          tabClickHandler.click(function () {
            const productCat = $(this).attr('data-category-target-id');
            if (productCat) {
              const currentURL = (langCode !== undefined && langCode !== 'en') ? drupalSettings.path.baseUrl + langCode + '/virtual-try-on' : drupalSettings.path.baseUrl + 'virtual-try-on';
              window.location.href = currentURL + '?productCat=' + productCat;
            }
          });

          // Onload data fetch request.
          function initShadesLoad(nodeId, productParentcat = null) {
            let url = (langCode !== 'en') ? `/${langCode}/api/v/jfmproducts/${nodeId}?_format=json` : `/api/v/jfmproducts/${nodeId}?_format=json`;
            fetch(url)
            .then((response) => {
              return response.json();
            })
            .then((data) => {
              if (data.length == 0) {
                let message = `<footer class="search-faq-results-found">`+ Drupal.t('Oops! No results found') +`</footer>`;
                var emptyResult = $(".product-right-relative", context);
                emptyResult.empty();
                emptyResult.append(message);
                $('.spiner-wrapper').hide();
                return false;
              }
              $('.product-actions__buy').css("display", "block");
              initSdk(productParentcat);
              selectedProductHeader(data[0]);
              productHeaderDesktopMarkup(data[0]);
              insertShadowinagesItem(data);

              // Retain selected shade from product page.
              let queryParams = new URLSearchParams(window.location.search);
              let shadeUpc = queryParams.get('shade');
              let shadeItemClicked = null;
              if (shadeUpc != null && shadeUpc !== undefined) {
                shadeItemClicked = $(".product-shades").find(".product-shade__shade-item").find(`[data-product-upc='${shadeUpc}']`);
                shadeItemClicked = shadeItemClicked[0];
              }

              shadeClick();
              setSpinner(true);
              shareIconCopy();
              shareLinkPopup();
              sharePopupClose();
              $(".product-shade__item-wrapper").trigger('click', shadeItemClicked);
              showSelectedMessage();
            })
            .catch(function (error) {
              console.log(error);
            });
          }

          // Update text event for current selected item.
          function selectedItem(updatedText) {
            $(".product-shades__selected-text").text(updatedText);
          }

          // Click event to get node id.
          const productListingItem = $(".product-listing__card-item");
          const productBuyButton = $('.product-actions__buy');

          productListingItem.click(function () {
            setSpinner(false);
            productBuyButton.css('pointer-events', 'none').attr('disabled', true);
            productListingItem.removeClass("active");
            const nodeId = $(this).attr("data-product-id");
            $(this).addClass("active");
            let url = (langCode !== 'en') ? `/${langCode}/api/v/jfmproducts/${nodeId}?_format=json` : `/api/v/jfmproducts/${nodeId}?_format=json`;
            fetch(url)
              .then((response) => {
                return response.json();
              })
              .then((data) => {
                setSpinner(true);
                selectedProductHeader(data[0]);
                productHeaderDesktopMarkup(data[0]);
                insertShadowinagesItem(data);
                selectedItem('');
                shadeClick();
                showSelectedMessage();
                shareIconCopy();
                shareLinkPopup();
                sharePopupClose();
              })
              .catch(function (error) {
                console.log(error);
              });
          });

          function shadeClick() {
            // Apply shade in VTO on click.
            $(".product-shade__item-wrapper").click(function (event, shadeClicked) {
              var shade_element = $(this)
              if (shadeClicked != null && shadeClicked !== undefined) {
                  shade_element = $(shadeClicked);
              }             
              const productSku = shade_element.attr("data-sku");
              const nodeId = shade_element.attr("data-nid");

              productBuyButton.removeAttr('disabled').css('pointer-events', 'auto');
              $(".product-shade__item-wrapper").removeClass(
                "product-shade__item-wrapper--selected"
              );

              shade_element.addClass("product-shade__item-wrapper--selected");

              var updatedText = shade_element
                .find(".product-shade__shade-text")
                .text();


              var bg = shade_element
                .find(".product-shade__shade-img")
                .css("background-image");
              bg = bg.replace("url(", "").replace(")", "").replace(/\"/gi, "");
              selectedProductShadeImg(bg);

              $('.product-shades__no_shade_selected-label').hide();
              $('.product-shades__selected-label').show();

              selectedItem(updatedText);
              let url = (langCode !== 'en') ? `/${langCode}/api/v/jfmproducts/${nodeId}?_format=json` : `/api/v/jfmproducts/${nodeId}?_format=json`;
              fetch(url)
              .then((response) => {
                return response.json();
              })
              .then((data) => {
                data.map(function (item) {
                  if(item.nid == nodeId) {
                    selectedProductInfo(item.field_product_card);
                  }
                });
              })
              .catch(function (error) {
                console.log(error);
              });

              YMK.applyMakeupBySku(productSku);
            });

          }

          $(
            ".vto-btn-wrapper .product-list, .product-shades__shades-list-d-wrapper, .product-shades__shades-list-m-wrapper"
          ).overlayScrollbars({
            className: "os-theme-jfm",
            scrollbars: {
              visibility: "auto",
              clickScrolling: true,
            },
          });
          // shades replace markup
          function insertShadowinagesItem(data) {
            var childContent = "";
            data.map(function (item) {
              childContent += shadesItem(item);
            });
            var shadeContainer = $(".product-shades__shades-list", context);
            if (data.length > 16) {
              shadeContainer.addClass("product-shades__shades-list--inf");
            }
            shadeContainer.empty();
            shadeContainer.append(childContent);
          }

          // shades markup
          function shadesItem(item) {
            if (item !== undefined) {
              let itemUpc = item.field_shade_upc;
              if(itemUpc && itemUpc !== '' && itemUpc !== undefined) {
                itemUpc = itemUpc.replace(/\s+/g, '');
              }

              return ` <div class="product-shade__shade-item">
                  <div class="product-shade__item-wrapper" data-nid="${item?.nid}" data-sku="${
                    item?.field_sku
                  }" data-product-upc="${itemUpc}" data-product-cat="${item.field_product_category}">
                    <div class="product-shade__shade-img" style="background-image: url(${
                      item?.field_shade_images
                    })">
                      ${
                        item?.field_new == 'Yes'
                          ? `<span class="product-shade__new-tag">New</span>`
                          : ""
                      }</span>
                    </div>
                    <div class="product-shade__shade-text">
                      <div class="product-shade__shade-id">${
                        item?.field_shade_id
                      }</div>
                      <div class="product-shade__shade-name">${
                        item?.title_1
                      }</div>
                    </div>
                  </div>
                </div>`;
            }
          }

          // product info header section
          function productHeaderDesktopMarkup(item) {
            if (item !== undefined) {
              let childContent = `
             <div class="product-header__title-header">
                <h1 class="product-header__title">${item.title}</h1>
                <img src="/themes/custom/jfm/images/share-icon.svg" class="share-link"/>
              </div>
              <div class="product-header__tags">
                <ul class="product-header__tags-list">
                  <li class="product-header__tag-item coverage">
                    <img src="/themes/custom/jfm/images/coverage.svg" class="product-header__tag-item-img">
                    <span class="product-header__tag-item-text coverage">${item.field_coverage}</span>
                  </li>
                  <li class="product-header__tag-item time">
                    <img src="/themes/custom/jfm/images/time.svg" class="product-header__tag-item-img">
                    <span class="product-header__tag-item-text time">${item.field_time_to_apply}</span>
                  </li>
                  <li class="product-header__tag-item shades">
                    <img src="/themes/custom/jfm/images/shades.svg" class="product-header__tag-item-img">
                    <span class="product-header__tag-item-text shades">${item.field_number_of_shades}</span>
                  </li>
                </ul>
              </div>

                      <div class="product-header__reviews">
                <div class="product-header__review-star">
                  <span class="product-header__review-rate">${item.field_ratings}</span>
                  <img class="product-header__review-img" src="/themes/custom/jfm/images/star-yellow.svg">
                </div>
                <span class="product-header__review-nos">${item.field_number_of_reviews}</span>
              </div>`;
              var shadeContainer = $(".product-header-desktop", context);
              let childpopupContent = productItmes(item);
              var shadeContainerpopup = $(".product-header-desktop-popup", context);
              shadeContainer.empty();
              shadeContainerpopup.empty();
              shadeContainer.append(childContent);
              shadeContainerpopup.append(childpopupContent);
            }
          }

          // function for share product content
          function productItmes(item) {
            if (item == undefined) {
              return false;
            }

            return `<div class="popup">
              <div class="popup-overlay"></div>
              <div class="share-wrapper">
                <div class="share-popup">
                  <div>
                    <img src="/themes/custom/jfm/images/close.svg" alt="close-icon" class="close-popup"/>
                  </div>
                  <div class="share-popup-block">
                    <div class="product-header__product-image">
                      <img src="${item.field_product_image}"/>
                    </div>
                    <div class="share-popup-detail">
                      <div class="product-header__title-header">
                        <h1 class="product-header__title">${item.title}</h1>
                      </div>
                      <div class="product-header__tags">
                        <ul class="product-header__tags-list">
                          <li class="product-header__tag-item coverage">
                            <img src="/themes/custom/jfm/images/coverage.svg" class="product-header__tag-item-img"/>
                            <span class="product-header__tag-item-text coverage">${item.field_coverage}</span>
                          </li>
                          <li class="product-header__tag-item time">
                            <img src="/themes/custom/jfm/images/time.svg" class="product-header__tag-item-img"/>
                            <span class="product-header__tag-item-text time">${item.field_time_to_apply}</span>
                          </li>
                          <li class="product-header__tag-item shades">
                            <img src="/themes/custom/jfm/images/shades.svg" class="product-header__tag-item-img"/>
                            <span class="product-header__tag-item-text shades">${item.field_number_of_shades}</span>
                          </li>
                        </ul>
                      </div>
                      <div class="product-header__reviews">
                        <div class="product-header__review-star">
                          <span class="product-header__review-rate">${item.field_ratings}</span>
                          <img class="product-header__review-img" src="/themes/custom/jfm/images/star-yellow.svg"/>
                        </div>
                        <span class="product-header__review-nos">${item.field_number_of_reviews} </span>
                      </div>
                    </div>
                  </div>
                  <div id="block-socialsharelinks">
                    <div class="share-popup-social-icons">
                      <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                        <div class="addtoany-social-icon">
                          <a class="a2a_button_whatsapp"></a>
                          <span class="addtoany-social-label">Whatsapp</span>
                        </div>
                        <div class="addtoany-social-icon">
                          <a class="a2a_button_telegram"></a>
                          <span class="addtoany-social-label">Telegram</span>
                        </div>
                        <div class="addtoany-social-icon">
                          <a class="a2a_button_facebook_messenger"></a>
                          <span class="addtoany-social-label">Messenger</span>
                        </div>
                        <div class="addtoany-social-icon">
                          <a class="a2a_button_facebook"></a>
                          <span class="addtoany-social-label">Facebook</span>
                          </div>
                      </div>
                        <a href="javascript:void(0)" class="coh-link rewards-refer-a-friend-share-block-link" target="_self" id="copy-link" style="display:none;">${item.view_node}</a>
                        <a href="javascript:void(0)"  class="coh-button copy-link" id="copy-button"  type="button">Copy link</a>
                    </div>
                  </div>
                  <script async src="https://static.addtoany.com/menu/page.js"></script>
                </div>
              </div>
            </div>`;
          }

          // Share icon popup.
          function shareIconCopy() {
            // Copy link.
            $("#copy-button").click(function (element) {
              var temp = $("#copy-link").text();
              navigator.clipboard.writeText(temp);
            });
          }

          function shareLinkPopup() {
            // Copy link.
            $(".share-link").click(function (element) {
              //Mobile buying popup start
              element.preventDefault();
              $(".popup").addClass('is-open-popup');
              $('body').addClass('is-popup');
            });
          }

          function sharePopupClose() {
            // Copy link.
            $('.close-popup').click(function(){
              $(".popup").removeClass('is-open-popup');
              $('body').removeClass('is-popup');
            })
          }

          // Selected product info markup.
          function selectedProductHeader(item) {
            if (item !== undefined) {
              let childContent = ` <div class="product-selected-left">
                <img src="${item.field_product_image}" class="product-header__tag-item-img">
              </div>
              <div class="product-selected-right">
                <div class="product-header__title-header">
                  <h1 class="product-header__title">${item.title}</h1>
                </div>
                <div class="product-header__tags">
                  <ul class="product-header__tags-list">
                    <li class="product-header__tag-item coverage">
                      <img src="/themes/custom/jfm/images/coverage.svg" class="product-header__tag-item-img">
                      <span class="product-header__tag-item-text coverage">${item.field_coverage}</span>
                    </li>
                    <li class="product-header__tag-item time">
                      <img src="/themes/custom/jfm/images/time.svg" class="product-header__tag-item-img">
                      <span class="product-header__tag-item-text time">${item.field_time_to_apply}</span>
                    </li>
                    <li class="product-header__tag-item shades">
                      <img src="/themes/custom/jfm/images/shades.svg" class="product-header__tag-item-img">
                      <span class="product-header__tag-item-text shades">${item.field_number_of_shades}</span>
                    </li>
                  </ul>
                </div>
              </div>`;

              var shadeContainer = $(".product-header-selected", context);
              shadeContainer.empty();
              shadeContainer.append(childContent);
            }
          }

          function selectedProductInfo(description) {
            if (description !== undefined) {
              let childContent = `${description}`;
              var shadeContainer = $(".product-selected-info", context);
              shadeContainer.empty();
              shadeContainer.append(childContent);
            }
          }

          function selectedProductShadeImg(image) {
            if (image !== undefined) {
              let childContent = `<div class="product-shade__shade-img" style="background-image: url(${image})"></div>`;
              var shadeContainer = $(".product-selected-image", context);
              shadeContainer.empty();
              shadeContainer.append(childContent);
            }
          }

          // Buy action declaration.
          function buyingOptionAction() {
            const productActionsBuy = $(".product-actions__buy");
            if (productActionsBuy.length > 0) {
              productActionsBuy.on("click", function () {
                $(".vto-container").hide();
                $(".vto-btn-wrapper").addClass('buy-option-enabled');
                $(".product-selected-shades-wrapper").show();
              });
              if($(window).innerWidth() <= 767) {
                $('.accordion-icon').click(function(){
                  $(this).toggleClass('accordion-open');
                  $('.vto-btn-wrapper.buy-option-enabled .product-selected-info').toggle();
                });
              }
            }
          }

          // Close action declaration.
          function cancelBuyingSelectedOption() {
            const productActionsBuy = $(
              ".product-selected-shades-wrapper .product-cancel-buy"
            );

            if (productActionsBuy.length > 0) {
              productActionsBuy.on("click", function () {
                $(".vto-container").show();
                $(".vto-btn-wrapper").removeClass('buy-option-enabled');
                $(".product-selected-shades-wrapper").hide();
              });
            }
          }

          modalBox();

          function modalBox() {
            const updateButton = document.getElementById('updateDetails');
            const vtoDialog = document.getElementById('vtoDialog');
            const confirmBtn = vtoDialog.querySelector('#confirmBtn');
            const cancelBtn = vtoDialog.querySelector('#cancelBtn');

            // "Update details" button opens the <dialog> modally
            updateButton.addEventListener('click', function () {
              $(vtoDialog).show();
              $("body").addClass("dailog-open");
            });
            // "Confirm" button of form triggers "close" on dialog because of [method="dialog"]
            confirmBtn.addEventListener('click', function onClose() {
              $(vtoDialog).hide();
              redirectToReferrer();
              $('body').removeClass('dailog-open');
            });
              // "Confirm" button of form triggers "close" on dialog because of [method="dialog"]
            cancelBtn.addEventListener('click', function onClose() {
              $('body').removeClass('dailog-open');
              $(vtoDialog).hide();
            });
          }
          setSpinner(false);

          // Spinner.
          function setSpinner(spinner) {
             if(spinner) {
              $('.spiner-wrapper').hide();
              $('.product-shades').show().css('opacity','1');
             } else {
              $('.spiner-wrapper').show();
              $('.product-shades').hide().css('opacity','0');
             }
          }

          function productTabOperations(productCat = null) {
            if ($(".vto-product-listing").length) {
              $(".vto-product-listing .product-list__tab").each(function () {
                $(this).detach().appendTo(".product-list__tabs");
              });
              $('.vto-product-listing .product-list').hide();
              const nodeId = drupalSettings.vtoData.productId;
              const onloadTab = $('.vto-product-listing .product-listing__card-item');

              if(nodeId != 0) {
                onloadTab.each(function(item){
                  const nodeIdCurent = $(this).attr('data-product-id');
                  if(nodeId == nodeIdCurent) {
                    $(this).addClass('active');
                    $(this).parents('.product-list').show();
                    const dataCatagory = $(this).closest('.product-list').attr('data-category');
                    $('.product-list__tabs .product-list__tab').each(function() {
                      const dataCatagoryCurrent = $(this).attr('data-target');
                      if(dataCatagory == dataCatagoryCurrent) {
                        $(this).addClass('active');
                      }
                    });
                  }
                });
              }
              else {
                const nodeId = $(".vto-product-listing").find(".product-list").find(`[data-attr='${productCat}']:first`).attr('data-product-id');
                const productParentcat = $(".vto-product-listing").find(".product-list").find(`[data-attr='${productCat}']:first`).attr('data-attr');
                $(".vto-product-listing").find(".product-list").find(`[data-attr='${productCat}']:first`).addClass('active');
                let tabtragetcat = $(".vto-product-listing .product-list__tabs").find(`[data-category-target-id='${productCat}']`).attr('data-target');
                $(".vto-product-listing").find(`[data-target='${tabtragetcat}']`).addClass("active");
                $(".vto-product-listing").find(`[data-category='${tabtragetcat}']`).show();
                initShadesLoad(nodeId, productParentcat);
              }


              $(".product-list__tab").on("click", function () {
                $(".product-list__tab").removeClass("active");
                $(this).addClass("active");

                $(".vto-product-listing .product-list").hide();

                let activeTab = $(this).attr("data-target");
                $("div").find(`[data-category='${activeTab}']`).toggle();
              });
            }
          }

          // Set referrer.
          function setReferrer() {

            let currentPath = window.location.href;

            if (currentPath.includes("/virtual-try-on") == true) {
              let redirectUrl = null;
              let currentReferrer = document.referrer;
              let vtoReferrer = localStorage.getItem('vtoReferrer');

              if ((typeof currentReferrer !== undefined) && (currentReferrer.length !== 0) && (currentReferrer.includes("/virtual-try-on") !== true) ) {
                if (vtoReferrer == undefined || vtoReferrer.length == 0 || currentReferrer !== vtoReferrer) {
                  redirectUrl = currentReferrer;
                }
              }
              else if (vtoReferrer !== undefined || vtoReferrer.length !== 0) {
                redirectUrl = vtoReferrer;
              }
              else {
                redirectUrl = drupalSettings.path.baseUrl ? drupalSettings.path.baseUrl : "/";
              }

              if (redirectUrl == null) {
                redirectUrl = "/";
              }
              localStorage.setItem('vtoReferrer', redirectUrl);
            }
          }

          // Redirect to ReferenceError.
          function redirectToReferrer() {
            let redirectUrl = drupalSettings.path.baseUrl ? drupalSettings.path.baseUrl : "/";
            let referrer = localStorage.getItem('vtoReferrer');
            if (referrer !== undefined || referrer !== null) {
              redirectUrl = referrer;
            }
            if (redirectUrl == null) {
              redirectUrl = "/";
            }
            localStorage.removeItem('vtoReferrer');
            window.location.href = redirectUrl;
          }

          /**
           * Move current product to first position.
           */
          function moveProduct(nodeId) {
            $('.product-listing__card-item').each(function() {
              if ($(this).hasClass('active')) {
                let productItem = $(this).parent().parent().parent();
                let productParent = productItem.parent();
                productItem.detach().prependTo(productParent);
              }
            });
          }

          /**
           * Show no shade selected message.
           */
          function showSelectedMessage() {
            // Show selected mesasge onLoad.
            if ($('.product-shade__item-wrapper').hasClass('product-shade__item-wrapper--selected')) {
              $('.product-shades__no_shade_selected-label').hide();
              $('.product-shades__selected-label').show();
            }
            else {
              $('.product-shades__selected-label').hide();
              $('.product-shades__no_shade_selected-label').show();
            }
          }

          showSelectedMessage();

        });

      // Render embedded mikmak buy script.
      $(".product-actions__buy").once("mikmak-buy").on("click", function() {
        // spinner
        function setBuySpinner(spinner) {
          if(spinner) {
            $('.spinner-wrapper-buy').hide();
            $('.product-mikmak').show().css('opacity','1');
          } else {
            $('.spinner-wrapper-buy').show();
            $('.product-mikmak').hide().css('opacity','0');
          }
        }

        $(".product-mikmak").html('');
        let productUpc = $(".product-shade__item-wrapper--selected").attr("data-product-upc");
        productUpc = productUpc.replace(/\s+/g, '');
        if (productUpc && productUpc !== '' && productUpc !== undefined) {
          const url = `/mikmak?productUpc=${productUpc}`;
          // Get mikmak controller output.
          $.ajax({
            type: 'GET',
            url: url,
            beforeSend: function() {
              setBuySpinner(true);
            },
            success: function(data) {
              $(".product-mikmak").html(data).fadeIn();
            },
            complete: function() {
              setTimeout(function(){
                setBuySpinner(true);
              },500);
            }
          });
        }
      });

      // Remove last rendered mikmak script.
      $(".product-cancel-buy").once("mikmak-cancel-buy svg").on("click", function() {
        $(".product-mikmak").html('');
      });
    },
  };
})(jQuery, Drupal, drupalSettings);
