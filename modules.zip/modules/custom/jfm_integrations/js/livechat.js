/**
 * LiveChat Integration.
 */

(function ($, Drupal) {
  Drupal.behaviors.jfm_integrations_livechat = {
    attach: function (context, drupalSettings) {
      'use strict';

      $('html', context).once('livechat').each(function () {

        window.astuteBotMessengerSettings = {
          channelId: drupalSettings.livechat.channelId
        };

        function includeScript(e){
          var t = document.createElement("script"),
            n = document.getElementsByTagName("script")[0];
            t.type = "text/javascript",
            t.src = e,t.async = !0,
            n.parentNode.insertBefore(t,n)
        }

        includeScript(drupalSettings.livechat.apiEndpoint);

        let chatElement = $('.rewards-chat-now-link-column, .ask-a-question-chat__link');
        if (undefined != chatElement || chatElement != null) {
          chatElement.click(function (e) {
            e.preventDefault();
            showChat();
          });
        }

        /**
         * Show Chat popup.
         */
        function showChat() {
          if (("undefined" == typeof astuteBotMessenger)) {
            return console.warn("Chat not available");
          }

          window.astuteBotMessenger.sendEvent(
            {
              name: "Bot",
              index: 0
            },
            {
              type: "startConversation",
              initialUserMessage: {
                type: "text",
                content: {
                  speech: "Chat with Agent"
                }
              }
            }
          );

        }

      });
    }
  }
})(jQuery, Drupal, drupalSettings);
