<?php

namespace Drupal\jfm_integrations\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Config\ConfigFactory;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a block called "Live Chat Integration Block".
 *
 * @Block(
 *  id = "jfm_integrations_live_chat",
 *  admin_label = @Translation("Live Chat Integration Block")
 * )
 */
class LiveChatBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Configuration.
   *
   * @var Drupal\Core\Config\ConfigFactory
   */
  protected $config;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, ConfigFactory $config_factory) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->config = $config_factory->get('jfm_integrations.livechat_settings');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('<div class="live-chat"></div>'),
      '#attached' => [
        'library' => [
          'jfm_integrations/livechat',
        ],
        'drupalSettings' => [
          'livechat' => [
            'channelId' => $this->config->get('channelId'),
            'apiEndpoint' => $this->config->get('apiEndpoint'),
          ],
        ],
      ],
    ];
  }

}
