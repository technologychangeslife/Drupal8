<?php

namespace Drupal\jfm_integrations\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a block called "MikMak Block".
 *
 * @Block(
 *  id = "jfm_integrations_mikmak",
 *  admin_label = @Translation("MikMak Block")
 * )
 */
class MikMakBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('<div class="mikmak"></div>'),
    ];
  }

}
