<?php

namespace Drupal\jfm_integrations\Plugin\Field\FieldFormatter;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\Plugin\Field\FieldFormatter\EntityReferenceFormatterBase;
use Drupal\taxonomy\TermInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Plugin implementation of the 'entity_reference_root_term_field' formatter.
 *
 * @FieldFormatter(
 *   id = "entity_reference_root_term_field",
 *   label = @Translation("Root term Field"),
 *   description = @Translation("Display label of the root term for this term field."),
 *   field_types = {
 *     "entity_reference"
 *   }
 * )
 */
class WithoutTranslatedRootTermFieldNameFormatter extends EntityReferenceFormatterBase {

  /**
   * The storage handler class for taxonomy.
   *
   * @var \Drupal\taxonomy\TermStorage
   */
  protected $termStorage;

  /**
   * Construct.
   */
  public function __construct(
    $plugin_id,
    $plugin_definition,
    FieldDefinitionInterface $field_definition,
    array $settings,
    $label,
    $view_mode,
    array $third_party_settings,
    EntityTypeManagerInterface $entity
  ) {
    parent::__construct($plugin_id, $plugin_definition, $field_definition, $settings, $label, $view_mode, $third_party_settings);
    $this->termStorage = $entity->getStorage('taxonomy_term');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $plugin_id,
      $plugin_definition,
      $configuration['field_definition'],
      $configuration['settings'],
      $configuration['label'],
      $configuration['view_mode'],
      $configuration['third_party_settings'],
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $originalfield = '';
    foreach ($this->getEntitiesToView($items, $langcode) as $delta => $item) {
      /* todo handle multiple values */
      if ($item instanceof TermInterface) {
        $ancestors = $this->termStorage->loadAllParents($item->id());
        $root = end($ancestors);
        $originalfield = $root->get('field_target_id')->value;
      }
    }
    return [['#markup' => $originalfield]];
  }

  /**
   * {@inheritdoc}
   */
  public static function isApplicable(FieldDefinitionInterface $field_definition) {
    // This formatter is only available for taxonomy terms.
    return $field_definition->getFieldStorageDefinition()->getSetting('target_type') == 'taxonomy_term';
  }

}
