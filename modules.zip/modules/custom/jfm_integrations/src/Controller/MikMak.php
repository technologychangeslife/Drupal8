<?php

namespace Drupal\jfm_integrations\Controller;

use Drupal\Core\Config\ConfigFactory;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Routing\CurrentRouteMatch;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class MikMak for serving the VTO page.
 */
class MikMak extends ControllerBase {

  /**
   * Product UPC.
   *
   * @var string
   */
  protected $productUpc;

  /**
   * Configuration.
   *
   * @var Drupal\Core\Config\ConfigFactory
   */
  protected $config;

  /**
   * Route match object.
   *
   * @var Drupal\Core\Routing\CurrentRouteMatch
   */
  protected $routeMatch;

  /**
   * Request object.
   *
   * @var Symfony\Component\HttpFoundation\RequestStack
   */
  protected $request;

  /**
   * Route match object.
   *
   * @var Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  public function __construct(ConfigFactory $config_factory,
    CurrentRouteMatch $route_match,
    LoggerChannelFactoryInterface $logger_factory,
    RequestStack $request_stack) {
    $this->config = $config_factory->get('jfm_integrations.mikmak_settings');
    $this->routeMatch = $route_match;
    $this->logger = $logger_factory->get('jfm_integrations');
    $this->request = $request_stack;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('current_route_match'),
      $container->get('logger.factory'),
      $container->get('request_stack'),
    );
  }

  /**
   * VTO page action.
   *
   * @return array
   *   Return markup of page.
   */
  public function content(Request $request) {

    $this->productUpc = $request->query->get('productUpc');
    $data = [
      'productUpc' => $this->productUpc,
      'config' => [
        'apikey' => $this->config->get('apikey'),
        'apiEndpoint' => $this->config->get('apiEndpoint'),
      ],
    ];

    $build = [
      '#theme' => 'mikmak',
      '#data' => $data,
      '#attached' => [
        'library' => [
          'jfm_integrations/mikmak',
        ],
        'drupalSettings' => [
          'mikMakData' => $data,
        ],
      ],
      '#cache' => [
        'contexts' => [
          'url.query_args',
        ],
      ],
    ];

    return $build;
  }

}
