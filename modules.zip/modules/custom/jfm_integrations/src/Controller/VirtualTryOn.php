<?php

namespace Drupal\jfm_integrations\Controller;

use Drupal\Core\Config\ConfigFactory;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Routing\CurrentRouteMatch;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class VirtualTryOnController for serving the VTO page.
 */
class VirtualTryOn extends ControllerBase {

  /**
   * A node product object.
   *
   * @var Drupal\Node\NodeInterface
   */
  protected $product;

  /**
   * Product id.
   *
   * @var int
   */
  protected $productId;

  /**
   * A entityTypeManager variable.
   *
   * @var Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Configuration.
   *
   * @var Drupal\Core\Config\ConfigFactory
   */
  protected $config;

  /**
   * Route match object.
   *
   * @var Drupal\Core\Routing\CurrentRouteMatch
   */
  protected $routeMatch;

  /**
   * Route match object.
   *
   * @var Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager,
    ConfigFactory $config_factory,
    CurrentRouteMatch $route_match,
    LoggerChannelFactoryInterface $logger_factory) {
    $this->entityTypeManager = $entity_type_manager;
    $this->config = $config_factory;
    $this->routeMatch = $route_match;
    $this->productId = $this->routeMatch->getParameter('product_id');
    $this->logger = $logger_factory->get('jfm_integrations');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('config.factory'),
      $container->get('current_route_match'),
      $container->get('logger.factory')
    );
  }

  /**
   * VTO page action.
   *
   * @return array
   *   Return markup of page.
   */
  public function content() {

    // Load mikmak config for mikmak script to render on vto.
    $mikmak_config = $this->config->get('jfm_integrations.mikmak_settings');
    $mikmak_config_data = [
      'config' => [
        'apikey' => $mikmak_config->get('apikey'),
        'apiEndpoint' => $mikmak_config->get('apiEndpoint'),
      ],
    ];

    // Load vto config.
    $vto_config = $this->config->get('jfm_integrations.vto_settings');
    $data = [
      'productId' => (int) $this->productId,
      'productCategory' => $this->getProductCategory(TRUE),
      'config' => [
        'vto_hair_endpoint' => $vto_config->get('vto_hair_endpoint'),
        'vto_beard_endpoint' => $vto_config->get('vto_beard_endpoint'),
        'vto_apiEndpoint' => $vto_config->get('vto_apiEndpoint'),
        'vto_apikey' => $vto_config->get('vto_apikey'),
      ],
      'productListBlock' => $this->getBlockContent(),
    ];

    $meta_description = $this->t("Our Men's Hair Color Virtual Try On tool can be used for head hair or facial hair. You can find your natural-looking shade via live cam or photo upload.");

    $build = [
      '#theme' => 'virtual_try_on',
      '#data' => $data,
      '#attached' => [
        'library' => [
          'jfm_integrations/vto',
        ],
        'html_head' => [
          [
            [ '#tag' => 'meta',
              '#attributes' => [
                'name' => 'description',
                'content' => $meta_description,
              ],
            ],
            'description',
          ],
        ],
        'drupalSettings' => [
          'vtoData' => $data,
          'mikMakData' => $mikmak_config_data,
        ],
      ],
    ];

    return $build;
  }

  /**
   * Get product category.
   *
   * @param bool $return_parent
   *   True if you want to have parent category, otherwise selected category.
   *
   * @return array
   *   Return array of categories.
   */
  protected function getProductCategory($return_parent = FALSE) {
    $terms = '';
    $this->product = $this->entityTypeManager->getStorage('node')->load($this->productId);
    if ($this->product) {
      $tids = $this->product->field_product_category->getValue();
      if (is_array($tids) && !empty($tids[key($tids)]['target_id'])) {
        $product_categoryid = $tids[key($tids)]['target_id'];
        if ($return_parent == TRUE) {
          $parents = $this->entityTypeManager->getStorage("taxonomy_term")->loadAllParents($product_categoryid);
          $root_parent = end($parents);
          $terms = $root_parent->get('field_target_id')->value;
        }
        else {
          $term = $term = $this->entityTypeManager->getStorage("taxonomy_term")->load($product_categoryid);
          $terms = $term->get('field_target_id')->value;
        }
      }
    }
    return $terms;
  }

  /**
   * Get Block Content.
   */
  protected function getBlockContent() {
    $block_content = NULL;
    try {
      $block_content = views_embed_view('vto_product_listing', 'product_listing_block');
    }
    catch (\Exception $e) {
      $this->logger->error($e->getMessage());
    }

    return $block_content;
  }

}
