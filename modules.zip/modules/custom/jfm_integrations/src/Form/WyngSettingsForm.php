<?php

namespace Drupal\jfm_integrations\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * WyngSettingsForm class for settings page.
 *
 * @package Drupal\jfm_integrations\Form
 */
class WyngSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'jfm_integrations_wyng_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['jfm_integrations.wyng_settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('jfm_integrations.wyng_settings');

    $form['wyng_brand'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Brand id'),
      '#default_value' => $config->get('wyng_brand'),
    ];

    $form['wyng_access_token'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Access Token'),
      '#default_value' => $config->get('wyng_access_token'),
    ];

    $form['wyng_sdk_profile_url'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Profile SDK Endpoint'),
      '#default_value' => $config->get('wyng_sdk_profile_url'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();

    $this->configFactory()->getEditable('jfm_integrations.wyng_settings')
      ->set('wyng_brand', $values['wyng_brand'])
      ->set('wyng_access_token', $values['wyng_access_token'])
      ->set('wyng_sdk_profile_url', $values['wyng_sdk_profile_url'])
      ->save();

    parent::submitForm($form, $form_state);
  }

}
