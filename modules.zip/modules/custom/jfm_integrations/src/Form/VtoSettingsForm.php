<?php

namespace Drupal\jfm_integrations\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * VtoSettingsForm class for settings page.
 *
 * @package Drupal\jfm_integrations\Form
 */
class VtoSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'jfm_integrations_vto_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['jfm_integrations.vto_settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $config = $this->config('jfm_integrations.vto_settings');

    $form['vto_hair_endpoint'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Hair Endpoint'),
      '#default_value' => $config->get('vto_hair_endpoint'),
    ];

    $form['vto_beard_endpoint'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Beard Endpoint'),
      '#default_value' => $config->get('vto_beard_endpoint'),
    ];

    $form['vto_apiEndpoint'] = [
      '#type' => 'textfield',
      '#title' => $this->t('API Endpoint'),
      '#default_value' => $config->get('vto_apiEndpoint'),
    ];

    $form['vto_apikey'] = [
      '#type' => 'textfield',
      '#title' => $this->t('API Key'),
      '#default_value' => $config->get('vto_apikey'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();

    $this->configFactory()->getEditable('jfm_integrations.vto_settings')
      ->set('vto_hair_endpoint', $values['vto_hair_endpoint'])
      ->set('vto_beard_endpoint', $values['vto_beard_endpoint'])
      ->set('vto_apiEndpoint', $values['vto_apiEndpoint'])
      ->set('vto_apikey', $values['vto_apikey'])
      ->save();

    parent::submitForm($form, $form_state);
  }

}
