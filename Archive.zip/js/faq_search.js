(function ($, Drupal) {

  function showHideChat(content) {
    if (content) {
      if (content.includes("general_que")) {
        $(".ask-a-question-chat").show();
      } else {
        $(".ask-a-question-chat").hide();
      }
    }
  }

  Drupal.behaviors.search_faqs = {
    attach: function (context, settings) {
      $('.js-search-faq .views-row:first').addClass('is-active');
      $('.js-search-faq .views-row:first.is-active .faq_answer_description').slideDown('fast');
      $('.js-search-faq .faq_question_title').click(function () {
        var thisRow = $(this).parent('.views-row');
        if (thisRow.hasClass('is-active')) {
          thisRow.find('.faq_answer_description').slideUp('fast');
          thisRow.removeClass('is-active');
        } else {
          thisRow.find('.faq_answer_description').slideDown('fast');
          thisRow.addClass('is-active');
        };

      });

      if ($('.search-faqs-centered .bef-exposed-form .product-list ul li .form-item input[checked="checked"]').length) {
        let identifier = $('.search-faqs-centered .product-list ul li .form-item input[checked="checked"]');
        $(identifier).parent("li").siblings().removeClass("active");
        $(identifier).parent("li").siblings().find("ul li").removeClass("active");
        $(identifier).parents("li").addClass("active");
      }
      else {
        $(".search-faqs-centered .bef-exposed-form .product-list ul>li:nth-child(2)").once().addClass("active");
      }

      function searchFaqAddCssProperty() {
        var height = $('.search-faqs-centered .bef-nested>ul.hasChild>li>ul').outerHeight();
        $('.search-faqs-centered .bef-nested>ul.hasChild').css('height', (height + 36) + 'px')
        $('.search-faqs-centered .bef-nested>ul.hasChild>li>ul').css('top', (height + 30) + 'px');
      }

      $(document).ajaxSuccess(function (event, request, settings) {
        if (settings?.extraData?.view_name == 'search_faq') {
          const activeli = $('.search-faqs-centered .product-list .bef-nested ul li.active');
          if (activeli.find('ul').length > 0) {
            if (activeli.find('.label-parent').length > 0) {
              var label_parent = activeli.find('.label-parent').html();
              if (label_parent.length > 0) {
                activeli.find('.label-parent').remove();
                activeli.find('ul').prepend('<li class="parent-taxonomy-label">' + label_parent + '</li>');
              }
            }
            activeli.parent('ul').addClass('hasChild');
            activeli.find('ul').removeClass('hasChild');
          } else {
            activeli.parent('ul').removeClass('hasChild');
          }
        };
        searchFaqAddCssProperty();
        request.responseJSON &&
          request.responseJSON[2] &&
          request.responseJSON[2].data &&
        showHideChat(request.responseJSON[2].data);
      });

      $(window).resize(function(){
        searchFaqAddCssProperty();
      });
    },
  };
})(jQuery, Drupal )


