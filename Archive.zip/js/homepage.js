(function ($, Drupal, once, _, Backbone) {
  Drupal.behaviors.testimonial = {
    attach: function (context, settings) {
      if($("#testimonial div").hasClass("testimonial-list-carousel")){
        $(".testimonial-list-carousel").not('.slick-initialized').slick({
          dots: true,
          arrows: false,
          infinite: false,
          slidesToShow: 4,
          slidesToScroll: 1,
          responsive: [{
              breakpoint: 1351,
              settings: {
                arrows: true,
              },
            },
            {
              breakpoint: 993,
              settings: {
                arrows: false,
                slidesToShow: 3,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 567,
              settings: {
                arrows: false,
                centerPadding: '60px',
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
              },
            },
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ],
        })
      }
    },
  }
  //@TODO Removed slick from Homepage THE MOST OPTIONS. THE MOST SHADES component.
  // Drupal.behaviors.productlist = {
  //   attach: function (context, settings) {
  //     var $productslider = $('.product-listing__row')
  //     var $productprogressBar = $('.slider-progress-bar')
  //     var $productprogressBarLabel = $('.slider-progress-bar-label')
  //     $productslider.on('beforeChange', function (
  //       event,
  //       slick,
  //       currentSlide,
  //       nextSlide,
  //     ) {
  //       var calc = (nextSlide / (slick.slideCount - 1)) * 100

  //       $productprogressBar
  //         .css('background-size', calc + '% 100%')
  //         .attr('aria-valuenow', calc)

  //       $productprogressBarLabel.text(calc + '% completed')
  //     })
  //     $productslider.slick({
  //       dots: false,
  //       arrows: false,
  //       autoplay: true,
  //       slidesToShow: 4,
  //       slidesToScroll: 1,
  //       speed: 400,
  //       responsive: [
  //         {
  //           breakpoint: 1400,
  //           settings: {
  //             slidesToShow: 3,
  //             slidesToScroll: 1,
  //           },
  //         },
  //         {
  //           breakpoint: 992,
  //           settings: {
  //             slidesToShow: 2,
  //             slidesToScroll: 1,
  //           },
  //         },
  //         {
  //           breakpoint: 768,
  //           settings: {
  //             slidesToShow: 1,
  //             slidesToScroll: 1,
  //           },
  //         },
  //       ],
  //     })
  //   },
  // }
  // jfm crew dropdown
  Drupal.behaviors.jfmcrew = {
    attach: function (context, settings) {

      $(document).ready(function () {
        $(".jfm-crew-block")
          .once("jfm-crew-block-init")
          .each(function () {

            $(".jfm-crew-block").addClass('not-collapsed');

            $(".jfm-crew-section").click(function (e) {
              e.preventDefault();
              if ($("#qnimate").hasClass("popup-box-on")) {
                $(".popup-box-on").css("display", "none");
                $("#qnimate").removeClass("popup-box-on");
                $(this).parents().find(".jfm-crew-block").addClass("collaped");
              } else {
                $("#qnimate").addClass("popup-box-on");
                $(".popup-box-on").css("display", "block");
                $(this)
                  .parents()
                  .find(".jfm-crew-block")
                  .removeClass("collaped");
              }
            });
            $("#removeClass").click(function () {
              $("#qnimate").removeClass("popup-box-on");
              $(".jfm-crew-block").css("display", "none");
              $(this).parents().find(".jfm-crew-block").removeClass("visible");
            });
          });
      });
    },
  }
})(jQuery, Drupal, once, window._, window.Backbone)
