import Global from "./Global.js";
(function ($, Drupal, once) {
  Drupal.behaviors.Module = {
    attach: function (context, settings) {
      $(document).ready(function () {

        // Product submenu tab.
        $(".products-submenu-button", context).click(function () {
          $(".products-submenu-block").slideToggle();
        });

        $(
          ".built-house-slider-row, .product-listing__row, .rewards-get-access-rows"
        ).overlayScrollbars({
          className: "os-theme-jfm",
          scrollbars: {
            visibility: "auto",
            clickScrolling: true,
          },
        });

        searchFaqAddCssProperty();
      });

      // Copy link.
      $("#copy-button").click(function (element) {
        var temp = $("#copy-link").text();
        navigator.clipboard.writeText(temp);
      });

      function searchFaqAddCssProperty() {
        const activeListItem = $('.how-its-work .bef-nested>ul>li.active');
        var height = $('.how-its-work .bef-nested>ul>li>ul').outerHeight();
        if (activeListItem.find('ul').length > 0) {
          $('.how-its-work .bef-nested>ul', context).css('height', (height + 29) + 'px')
          $('.how-its-work .bef-nested>ul>li>ul', context).css('top', (height + 29) + 'px');
        } else {
          $('.how-its-work .bef-nested>ul', context).removeAttr('style');
          $('.how-its-work .bef-nested>ul>li>ul', context).removeAttr('style');
        }
      };

      $(window).resize(function () {
        searchFaqAddCssProperty();
      });
    },
  };

  //for product listing filters
  Drupal.behaviors.product_facet_filters = {
    attach: function (context, settings) {
      $(".product-listing-bef-radio .product-list ul>li:nth-child(1)")
        .once()
        .addClass("active");
      $(document).on(
        "click",
        ".product-listing-bef-radio .product-list ul li .form-item",
        function (e) {
          if ($(this).find("input").is(":checked")) {
            $(this).parent("li").siblings().removeClass("active");
            $(this).parent("li").siblings().find("ul li").removeClass("active");
            $(this).parent("li").addClass("active");
            // If selected term has All as first element it should be highlighted by default.
            if (
              $(this).parent("li").find("ul>li").length !== 0 &&
              $(this)
              .parent("li")
              .find('ul>li:nth-child(1) [child-attr="select-all-nested"]')
              .length !== 0
            ) {
              $(this)
                .parent("li")
                .find("ul>li:nth-child(1)")
                .addClass("active");
            }
          }
        }
      );
    },
  };

  // Added check for email validation.
  function emailPatternValidation(email, event, parentClass) {
    var errorMsg = null;
    var mailformat =
      /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (email == "" || !email.match(mailformat)) {
      errorMsg = Drupal.t("Please enter valid email address");
      $(parentClass).find(".mauticform-error").html(errorMsg).show();
      event.preventDefault();
    }
  }

  Drupal.behaviors.rewardErrorMessage = {
    attach: function (context, settings) {
      $('#mauticform_rewardsformwebsitecampaign').attr('novalidate', 'novalidate');
      var emailWrapper = $('.rewards-join-the-jfm-crew-email-input #mauticform_wrapper_rewardsformwebsitecampaign');
      $(emailWrapper, context).submit(function (event) {
        var rewardEmail = $(this).find('#mauticform_input_rewardsformwebsitecampaign_email').val();
        var rewardsParent = '.rewards-join-the-jfm-crew-email-wrapper';
        emailPatternValidation(rewardEmail, event, rewardsParent);
      });
    },
  };

  Drupal.behaviors.signUpErrorMessage = {
    attach: function (context, settings) {
      $('.footer-signup-form #mauticform_rewardsformwebsitecampaign').attr('novalidate', 'novalidate');
      var signUpWrapper = $('.footer-signup-form #mauticform_wrapper_rewardsformwebsitecampaign');
      $(signUpWrapper, context).submit(function (event) {
        var signupEmail = $(this).find('#mauticform_input_rewardsformwebsitecampaign_email').val();
        var signupParent = '.footer-signup-form';
        emailPatternValidation(signupEmail, event, signupParent);
      });
    },
  };

  Drupal.behaviors.joinCrewErrorMessage = {
    attach: function (context, settings) {
      $('#mauticform_newslettersubscriptionformc').attr('novalidate', 'novalidate');
      $(
        ".jfm-crew-block #mauticform_wrapper_newslettersubscriptionformc",
        context
      ).submit(function (event) {
        var crewEmail = $(
          "#mauticform_wrapper_newslettersubscriptionformc #mauticform_input_newslettersubscriptionformc_email"
        ).val();
        var crewParent = '.jfm-crew-block';
        emailPatternValidation(crewEmail, event, crewParent);
      });
    },
  };

  Drupal.behaviors.signupRewards = {
    attach: function (context, settings) {
      var message = "";

      // Validate sign up rewards form.
      $(document).on(
        "submit",
        ".footer-signup-form #mauticform_rewardsformwebsitecampaign",
        function (event) {
          var signUpEmail = $(
            ".footer-signup-form #mauticform_input_rewardsformwebsitecampaign_email"
          ).val();
          emailPatternValidation(signUpEmail, event);
        }
      );

      $.urlParam = function (name) {
        var results = new RegExp("[?&]" + name + "=([^&#]*)").exec(
          window.location.href
        );
        if (results) {
          return results[1] || 0;
        }
      };
      message = $.urlParam("mauticMessage");

      if (message) {
        let submissionMessage = Drupal.t(message.replace(/%20/g, " "));

        // Display submission message.
        $("#block-jfm-content")
          .once()
          .prepend(
            '<div class="sign-up-messages">' + submissionMessage + "</div>"
          );
      }
    },
  };

  Drupal.behaviors.trending = {
    attach: function (context, settings) {
      const init = {
        autoplay: false,
        infinite: false,
        arrows: false,
        dots: true,
        cssEase: "linear",
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1259,
            settings: {
              arrows: false,
              slidesToShow: 3,
              slidesToScroll: 1,
            },
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
            },
          },
          {
            breakpoint: 415,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            },
          },
        ],
      };

      $(() => {
        const win = $(window);
        const slider = $(
          ".homepage-trending-slider-container .homepage-trending-slider"
        );
        win.on("load resize", () => {
          if (win.width() < 1260) {
            slider.not(".slick-initialized").slick(init);
          } else if (slider.hasClass("slick-initialized")) {
            slider.slick("unslick");
          }
        });
      });
    },
  };

  Drupal.behaviors.product_list = {
    attach: function (context, settings) {
      $(".product-list .js-form-item-term-node-tid-depth label")
        .once()
        .each(function () {
          var t = $(this).html();
          let labelStr = '';
          if (t.indexOf('<p>') !== -1) {
            labelStr = '<span class="tab-label">' +
              t.substring(0, t.indexOf('<p>')) +
              '</span>' +
              t.substring(t.indexOf('<p>'));
          } else {
            labelStr = '<span class="tab-label">' +
              t +
              '</span>';
          }
          $(this).html(labelStr);
        });
    },
  };

  // Add component count
  function addComponentCount(heading_title, count) {
    if (heading_title.length > 0) {
      heading_title.each(function () {
        count = count + 1;
        jQuery(this).addClass("component-" + count);
      });
    }
  }

  // Component count multiple time added
  Drupal.behaviors.componentCountMultipleTimeAdded = {
    attach: function (context, settings) {
      var count = 0;
      var heading_title = jQuery(".heading_title_with_text_container", context);
      addComponentCount(heading_title, count);
    },
  };

  // Component count multiple time added
  Drupal.behaviors.howItUseLineSeparator = {
    attach: function (context, settings) {
      var count = 0;
      var heading_title = jQuery(".how_it_use_line_separator", context);
      addComponentCount(heading_title, count);
    },
  };

  // Component count multiple time added
  Drupal.behaviors.titleComponent = {
    attach: function (context, settings) {
      var count = 0;
      var heading_title = jQuery(".title-container", context);
      addComponentCount(heading_title, count);
    },
  };

  // Rewards Copy clipboard css
  Drupal.behaviors.copybutton = {
    attach: function (context, settings) {
      $('#copy-button').on({
        "click": function () {
          $('.rewards-refer-a-friend-share-icon-wrapper button.coh-button').addClass(
            'copy-button-hover-icon',
          )
          setTimeout(function () {
            $('.rewards-refer-a-friend-share-icon-wrapper button.coh-button').removeClass(
              'copy-button-hover-icon',
            )
          }, 1000)
          $('.rewards-refer-a-friend-share-block-link').addClass(
            'copy-button-hover-text',
          )
          setTimeout(function () {
            $('.rewards-refer-a-friend-share-block-link').removeClass(
              'copy-button-hover-text',
            )
          }, 1000)
        },
      });
    },
  };

  // Select Country list.
  Drupal.behaviors.countrySelection = {
    attach: function (context, settings) {
      once("countrySelection", "html", context).forEach(function (element) {
        const globalValues = new Global();
        var data = globalValues.selectCountry();
        if (data != undefined) {
          if (data.icon != "undefined" || data.icon != null) {
            $(".jfm-flag-icon img").attr("src", data.icon);
          }

          if (data.name != "undefined" || data.name != null) {
            $(".jfm-country-name").text(data.name);
          }
        }

        $(".country-wrapper").on({
          click: function () {
            var name = $(this).find(".country-name").text();
            var icon = $(this).find(".flag-icon img").attr("src");
            globalValues.createStorage("selectedCountry", name);
            globalValues.createStorage("countryFlag", icon);
          },
        });
      });
    },
  };

  // Added class for testimonial mode title with text
  Drupal.behaviors.testimonialscarousel = {
    attach: function (context, settings) {
      if ($("#testimonial-with-image").hasClass('testimonial-list-carousel-without-image')) {
        $("#testimonial").addClass('testimonial-background-color-visibility');
      } else {
        $("#testimonial").removeClass('testimonial-background-color-visibility');
      }
    },
  };

  // contact form
  $(".mauticform-page-wrapper").each(function () {
    $(this).find('.mauticform-row').slice(1, 24).wrapAll("<div class='form-detail'></div>");
    $(this).find('.mauticform-row').slice(2, 23).wrapAll("<div class='personal-info'></div>");
    $(this).find('.mauticform-row').slice(2, 15).wrapAll("<div class='personal-block'></div>");
    $(this).find('.mauticform-row').slice(15, 23).wrapAll("<div class='personal-block'></div>");
  });

  //Product fimder retake section visible
  var finderSection = $('.page-node-type-products .product-finder-user-block');
  if ($(finderSection).length > 0) {
    $('#block-jfmproductsfinderbottomblock .retake-block').show();
  }
})(jQuery, Drupal, once)
