(function ($, Drupal, once) {
  Drupal.behaviors.hamburgerMenu = {
    attach: function (context, settings) {
      once("hamburgerMenu", "html", context).forEach(function (element) {
        $(document).ready(function () {
          // Open Tabs.
          function openTabs(evt, categoryName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
              tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
              tablinks[i].className = tablinks[i].className.replace(
                " active",
                ""
              );
            }
            $("." + categoryName).show();
            evt.currentTarget.className += " active";
          }

          let language_code = drupalSettings.path.currentLanguage;
          if (language_code === 'en') {
            $api_url = '/api/menu_items/hamburger-menu';
          }
          else {
            $api_url = '/'+ language_code+ '/api/menu_items/hamburger-menu';
          }

          // Call Api.
          $.ajax({
            url: $api_url,
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
            success: function (data, status, xhr) {
              createMenu(data);
              $(".jfm-hamburger-tabs .col:first>button").click();
              $(".onclick-menu-content").hide();
            },
          });

          // CreateMenus.
          let createMenu = function (data) {
            for (var i = 0; i < data.length; i++) {
              let subMenu = data[i].below;
              let menuTitle = data[i].title;
              let attributes = data[i].options;
              createSubMenu(menuTitle, attributes, subMenu);
            }
          };

          // CreateSubmenus.
          let createSubMenu = function (menuTitle, attributes = null, subMenu) {
            for (const submenus of subMenu) {
              let subMenuTitle = submenus.title;
              let classes = subMenuTitle.replace(/\s+/g, "");
              let menu_attribute = attributes.attributes.class[0];
              let queryParameter = submenus.field_query_parameter;
              let tabs = "";
              //Create Tabs and links.
              if (menu_attribute == "tabs") {
                let active = "";
                if (submenus.key[0]) {
                  active = "active";
                }
                tabs = `<div class="col"><button class="tablinks ${active}" data-list-target="${queryParameter}" data-category= ${classes}>${submenus.title}</div>`;
              }

              let path = submenus.relative;
              path = removeTrailinSlash(path);
              if (menu_attribute == "all-products") {
                $(".jfm-hamburger-view-all").append(
                  `<a href = ${path}> ${submenus.title}</a>`
                );
              }
              if (menu_attribute == "links" && submenus.enabled == true) {
                $(".jfm-hamburger-parent-links").append(
                  `<p><a href = ${path}> ${submenus.title}</a><p>`
                );
              }
              if (menu_attribute == "other-links" && submenus.enabled == true) {
                $(".jfm-hamburger-other-links").append(
                  `<p><a href = ${path}> ${submenus.title}</a><p>`
                );
              }

              if (submenus.below) {
                createInnerMenu(classes, submenus.below);
              }

              $(".jfm-hamburger-tabs").append(tabs);
            }
          };

          // Create Inner Menus.
          let createInnerMenu = function (classes, innerMenu) {
            for (const innermenus of innerMenu) {
              let innerMenuclasses = innermenus.title.replace(/\s+/g, "");
              let path = innermenus.relative;
              path = removeTrailinSlash(path);

              if (innermenus.options.query !== undefined) {
                let queryOptions = innermenus.options.query.term_node_tid_depth;
                if (queryOptions && queryOptions !== undefined) {
                  path += "?term_node_tid_depth=" + queryOptions;
                }
              }

              let subMenuDesc = "";
              if (innermenus.description !== null) {
                subMenuDesc = innermenus.description;
              }

              if (innermenus.enabled == true) {
                var links =
                  "<div class='tabcontent" +
                  " " +
                  classes +
                  "" +
                  "'> <ul class=" +
                  innerMenuclasses +
                  "><li><a href=" +
                  path +
                  ">" +
                  innermenus.title +
                  "</a><p>" +
                  subMenuDesc +
                  "</p></li></ul></div>";
                $(".jfm-hamburger-links").append(links);
              }

              if (innermenus.below) {
                $(".jfm-hamburger-links ." + innerMenuclasses + " " + "li:first").addClass(
                  "onclick-menu"
                ).parents('.tabcontent').addClass("onclick-menu-parent");

                for (const innermenus1 of innermenus.below) {
                  if (innermenus1.enabled == true) {
                    let path = innermenus1.relative;
                    path = removeTrailinSlash(path);
                    $("." + innerMenuclasses).append(
                      '<li class = "onclick-menu-content"><a href=' +
                        path +
                        ">" +
                        innermenus1.title +
                        "</a><p>" +
                        innermenus1.description +
                        "</p><li>"
                    );
                  }
                }
              }
            }
          };

          // Open tabs.
          $(document).on(
            "click",
            ".jfm-hamburger-tabs .col .tablinks",
            function (e) {
              openTabs(e, $(this).attr("data-category"));
            }
          );

          // Open child menus.
          $(document).on("click", ".onclick-menu", function (e) {
            $(this).closest("ul").find(".onclick-menu-content").toggle();
            $(this).toggleClass("icon-circle-arrow-down");
          });

          $(document).on("click", ".mobile-menu-button", function (e) {
            $(".jfm-hamburger-tabs .col:first>button").addClass("active");
            jQuery(document.body).toggleClass("menuOpen");
          });

          $(document).on("click", ".jfm-hamburger-view-all>a", function (event) {
            event.preventDefault();
            let eventLink = event.currentTarget.href;

            let queryParameter = null;
            $('.tablinks').each(function(){
              if ($(this).hasClass('active')) {
                queryParameter = $(this).data('list-target');
              }
            });

            if(queryParameter && queryParameter !== undefined) {
              eventLink += queryParameter;
            }

            if (eventLink && eventLink !== undefined) {
              window.location.href = eventLink;
            }
          });

          // User icon toggle.
          $('.user-profile')
            .once().on('click', function (e) {
              e.stopPropagation();
              $('.products-submenu-block').slideUp();
              $('.jfm-search-form').removeClass('open');
              $('html').removeClass('search-form-open');
              $(this).toggleClass('opened');
            });

          $(document).click(function () {
            $(".user-profile").removeClass('opened');
          });
        });
      });
      function removeTrailinSlash(url) {
        return url.replace(/\/+$/, '');
      }
    },
  };
})(jQuery, Drupal, once);
