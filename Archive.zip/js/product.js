(function ($, Drupal, once, _, Backbone) {
  Drupal.behaviors.productDetails = {
    attach: function (context, settings) {
      once("productDetailsComp", "html", context).forEach(function (element) {
        setBuySpinner(true);

        const langCode = settings.path.currentLanguage;

        let productApp = {
          views: {},
        };

        const domClassNames = {
          arrowLeft: "product-carousel__arrow-left",
          arrowRight: "product-carousel__arrow-right",
          carouselWrapper: "product-carousel__wrapper",
          shadesContainer: "product-shades",
          productShadeslist: "product-shades__shades-list",
          productCarouselArrowHide:
            "product-carousel__arrow-left--initial-hide",
          productCarouselNav: "product-carousel__nav",
          productCarouselNavButton: "product-carousel__nav-button",
        };

        function tpl(id) {
          return _.template($("#" + id).html());
        }

        productApp.views.carousel = Backbone.View.extend({
          el: "." + domClassNames.carouselWrapper,

          render: function () {
            this.collection.each(this.addImages, this);
            setSider(this.$el);
            return this;
          },

          addImages: function (model) {
            const view = new productApp.views.carouselImage({
              model: model,
            });
            this.$el.append(view.render().el);
          },
        });

        productApp.views.carouselImage = Backbone.View.extend({
          template: tpl("product-carousel-item"),

          render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
          },
        });

        productApp.views.productDetails = Backbone.View.extend({
          template: tpl("product-details-header"),

          render: function () {
            this.$el.html(this.template(this.model.toJSON()));

            if (this.model.get("field_coverage")) {
              this.$(".product-header__tag-item-text.coverage").text(
                this.model.get("field_coverage")
              );
              if (this.model.get("field_icon")) {
                this.$(".product-header__tag-item.coverage img").attr('src',
                  this.model.get("field_icon")
                );
              }
            } else {
              this.$(".product-header__tag-item.coverage").remove();
            }
            if (this.model.get("field_time_to_apply")) {
              this.$(".product-header__tag-item-text.time").text(
                this.model.get("field_time_to_apply")
              );
            } else {
              this.$(".product-header__tag-item.time").remove();
            }
            if (this.model.get("field_number_of_shades")) {
              this.$(".product-header__tag-item-text.shades").text(
                this.model.get("field_number_of_shades")
              );
            } else {
              this.$(".product-header__tag-item.shades").remove();
            }
            if (!this.model.get("nid_1")) {
              $(".product-shades").remove();
              $(".product-actions .product-actions__try").remove();
            }

            if (this.model.get("field_ratings")) {
              this.$(".product-header__review-rate").text(
                this.model.get("field_ratings")
              );
            } else {
              this.$(".product-header__review-star").remove();
            }

            if (this.model.get("field_number_of_reviews")) {
              this.$(".product-header__review-nos").text(
                this.model.get("field_number_of_reviews")
              );
            } else {
              this.$(".product-header__review-nos").remove();
            }
            return this;
          },
          events:{
            'click .share-link':'shareLinkEvent',
          },
          shareLinkEvent: function(e) {
            e.preventDefault();
            $(".popup").addClass('is-open-popup');
            $('body').addClass('is-popup');
          }
        });

        productApp.views.productShadeSelected = Backbone.View.extend({
          template: tpl("product-shade-selected"),

          render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
          },
        });

        productApp.views.productShades = Backbone.View.extend({
          el: "." + domClassNames.productShadeslist,

          render: function () {
            if (this.collection.length > 16) {
              this.$el.addClass("product-shades__shades-list--inf");
            }
            this.collection.each(this.addShades, this);
            return this;
          },

          addShades: function (model) {
            const view = new productApp.views.productShade({
              model: model,
              collection: this.collection,
            });
            this.$el.append(view.render().el);
          },
        });

        productApp.views.productShade = Backbone.View.extend({
          template: tpl("product-shade-item"),

          className: "product-shade__shade-item",

          render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            if (this.model.get("field_new") !== "Yes") {
              this.$(".product-shade__new-tag").remove();
            }
            // If Default Carousal is matching with any product shade
            // then it should be shown as selected.
            if (this.model.get('nid_1') === this.model.get('field_default_carousel')) {
              this.$el.find('.product-shade__item-wrapper').addClass('product-shade__item-wrapper--selected');
              $('.product-shades__shade-selected').show().attr('matching', true);
              this.model.set("is_selected", true);
            }
            else if(this.model.get('field_default_carousel') &&
              !$('.product-shades__shade-selected').attr('matching')
            ) {
              $('.product-shades__shade-selected').hide();
            }
            this.model.on("change:is_selected", this.toggleActive, this);
            return this;
          },

          events: {
            "click .product-shade__item-wrapper": "changeCarousel",
          },

          changeCarousel: function () {
            $(".product-shade__item-wrapper--selected").removeClass(
              "product-shade__item-wrapper--selected"
            );

            removeLeftArrowInitialClass();
            $(".product-carousel__wrapper").slick("unslick");
            $(".product-carousel__wrapper").html("");
            const activeModel = this.collection.findWhere({
              is_selected: true,
            });
            if (activeModel) {
              activeModel.set("is_selected", false);
            }
            this.model.set("is_selected", true);
            $('.product-shades__shade-selected').show();
            $('.product-actions__buy').removeAttr('title disabled');
            $('.product-actions__buy').attr('data-selected-shade', this.model.get('field_shade_upc'));
            $('.product-actions__try').attr('data-selected-shade', this.model.get('field_shade_upc'));
            const selectedShadeBg = this.model.get('field_shade_images');
            $('.product-selected-shade .product-shade__shade-img').css('background-image', `url(${selectedShadeBg})`);
            $('.product-selected-title .product-shades__selected-text').text(
              this.model.get("field_shade_id") + " " + this.model.get("title_1")
            );

            $(".product-shades__selected-text").text(
              this.model.get("field_shade_id") + " " + this.model.get("title_1")
            );
            createCarousel(this.model);
          },

          toggleActive: function () {
            if (this.model.get("is_selected")) {
              this.$(".product-shade__item-wrapper").addClass(
                "product-shade__item-wrapper--selected"
              );
              $('.product-actions__buy').css('pointer-events', 'unset');
              const selectedShadeUpc = this.model.get('field_shade_upc');
              if (selectedShadeUpc !== '') {
                $('.product-actions__buy').attr('data-selected-shade', selectedShadeUpc);
                const selectedShadeBg = this.model.get('field_shade_images');
                $('.product-selected-shade .product-shade__shade-img').css('background-image', `url(${selectedShadeBg})`);
                $('.product-selected-title .product-shades__selected-text').text(
                  this.model.get("field_shade_id") + " " + this.model.get("title_1")
                );
              }
            }
            else {
              this.$(".product-shade__item-wrapper").removeClass(
                "product-shade__item-wrapper--selected"
              );
              $('.product-actions__buy').attr('data-selected-shade', this.model.get(''));
              $('.product-selected-shade .product-shade__shade-img').css('background-image', '');
            }
          },
        });


        function customSliderButtons(slider, i) {
          return $(
            `<button class="${domClassNames.productCarouselNavButton}" type="button" />`
          );
        }

        // Get the node id from DrupalSettings
        function getNodeId() {
          if (settings && settings.path && settings.path.currentPath) {
            const strArr = settings.path.currentPath.split("/");
            return strArr[strArr.length - 1];
          }
        }

        // Get the data through the API call
        function getData() {
          const nodeId = getNodeId();
          if (!nodeId) {
            return;
          }
          let url = `/api/v/jfmproducts/${nodeId}?_format=json`;
          if (settings && settings.path && settings.path.currentLanguage) {
            const langCode = settings.path.currentLanguage;
            url = (langCode !== 'en') ? `/${langCode}/api/v/jfmproducts/${nodeId}?_format=json` : url;
          }
          $.ajax({
            url: url,
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
            success: function (data, status, xhr) {
              setData(data);
            },
          });
        }

        productApp.views.productActions = Backbone.View.extend({
          template: tpl("product-action-btns"),

          render: function () {
            let vtoUrl = "/virtual-try-on/" + this.model.get("nid");
            if (langCode !== undefined && langCode !== "en") {
              vtoUrl = "/" + langCode + vtoUrl;
            }
            this.model.set("vto_url", vtoUrl);
            this.$el.html(this.template(this.model.toJSON()));
            // Remove VTO button if disable vto experience is Yes.
            if (this.model.get("disable_vto_experience") == "Yes") {
              $(".product-actions .product-actions__try").remove();
            }
            return this;
          },
          events: {
            'click .product-actions__buy': "productBuyRedirection",
            'click .product-actions__try': "productTryRedirection",
          },

          productBuyRedirection: function(event){
            let selectedNid = event.currentTarget.dataset.selectedShade;
            selectedNid = selectedNid.replace(/\s+/g, '');
            if(selectedNid && selectedNid !== '' && selectedNid !== undefined) {
              $('.shades-wrapper-list').hide();
              $('.product-selected-shades-wrapper').show();
              $('.product-selected-shade').show();

              //Mobile buying popup start
              if($(window).innerWidth() <= 767) {
                $('body').addClass('body-overflow-popup');
                $('.buy-detail-popup').show();
                //info accordion on mobile for PDP page
                if($('.buy-detail-popup').is(':visible') && $('.buy-detail-popup .product-selected-info ul').length > 0) {
                  $('.accordion-icon').show();
                  $('.accordion-icon').click(function(){
                    $(this).toggleClass('accordion-open');
                    $('.buy-detail-popup .product-selected-info').toggle();
                  });
                }

              }
              //Mobile buying popup end
              $(".product-mikmak").html('');
                const url = `/mikmak?productUpc=${selectedNid}`;
                // Get mikmak controller output.
                $.ajax({
                  type: 'GET',
                  url: url,
                  beforeSend: function() {
                    setBuySpinner(true);
                  },
                  success: function(data) {
                    $(".product-mikmak").html(data).fadeIn();
                  },
                  complete: function() {
                    setTimeout(function(){
                      setBuySpinner(true);
                    },500);
                  }
                });

            }
            //selectd shade column overlap the finder
            var productFinder = $('.product-finder-user-block');
            if($(window).innerWidth() >= 992) {
              if((productFinder).length > 0  && $('.buy-detail-wrapper .product-selected-shade').css("display") == "block"){
                $('.product-selected-shade').parents('.product-details-right').addClass('overlap-finder');
              }
            }
          },

          productTryRedirection: function(event) {
            event.preventDefault();
            let eventLink = event.currentTarget.href;
            
            let currentShadeUpc = event.currentTarget.dataset.selectedShade;
            if(currentShadeUpc && currentShadeUpc !== '' && currentShadeUpc !== undefined) {
              currentShadeUpc = currentShadeUpc.replace(/\s+/g, '');
              eventLink += "?shade=" + currentShadeUpc;
            }

            if (eventLink && eventLink !== undefined) {
              window.location.href = eventLink;
            }
          },

        });

        function setBuySpinner(spinner) {
          if(spinner) {
            $('.spinner-wrapper-buy').hide();
            $('.product-mikmak').show().css('opacity','1');
          } else {
            $('.spinner-wrapper-buy').show();
            $('.product-mikmak').hide().css('opacity','0');
          }
        }

        productApp.views.productSelectedItem = Backbone.View.extend({
          template: tpl("product-selected-shades-buy"),

          render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
          },

          events: {
            'click .product-cancel-buy': "productTryClose",
          },

          productTryClose: function(event){
              $('.product-mikmak').html('');
              setBuySpinner(true);
              $('.shades-wrapper-list').show();
              $('.product-selected-shades-wrapper').hide();
              $('.product-selected-shade').hide();
              //Mobile buying popup
              $('body').removeClass('body-overflow-popup');

              //selectd shade column remove overlap from the finder
              $('.product-selected-shade').parents('.product-details-right').removeClass('overlap-finder');
          },

        });

        function setImageData(productDetails) {
          productDetails.carousel_images = getCarouselImages(productDetails);
          productDetails.default_images = getCarouselImages(productDetails, 'default');
          return productDetails;
        }

        // Build the component on successful retrivel of data
        function setData(data) {
          if (!data.length) {
            return;
          }
          const collection = new Backbone.Collection(data.map(setImageData));
          const model = collection.at(0);
          // Initial Carousal selection based on default value.
          if (model.get('field_default_carousel')) {
            createCarousel(collection.at(0), 'default');
          }
          else {
            createCarousel(collection.at(0));
          }

          // Create Desktop components
          createComponents(
            collection,
            model,
            $(".product-header-desktop"),
            $(".product-shades-selected-desktop"),
            $(".product-shades-list-desktop"),
            $(".product-actions-desktop"),
            $(".product-selected-shade")
          );
          createComponents(
            collection,
            model,
            $(".product-header-mobile"),
            $(".product-shades-selected-mobile"),
            $(".product-shades-list-mobile"),
            $(".product-actions-mobile"),
            $(".product-selected-shade")
          );
          $(
            ".product-shades__shades-list-m-wrapper, .product-shades__shades-list-d-wrapper"
          ).overlayScrollbars({
            className: "os-theme-jfm",
            scrollbars: {
              visibility: "auto",
              clickScrolling: true,
            },
          });
          // If no default carousel selected. Set first item as selected.
          if (!model.get('field_default_carousel')) {
            model.set("is_selected", true);
          }
          // If default item is selected.
          else {
            // Pick carousel shade.
            let currentActiveShade = collection.findWhere({
              is_selected: true,
            });
            // Check if shade UPC exists.
            if (currentActiveShade && currentActiveShade.get('field_shade_upc') !== '' && $('.product-shades__shade-selected').attr('matching')) {
              // Set buy button attr to carousel shade.
              $('.product-actions__buy').attr('data-selected-shade', currentActiveShade.get('field_shade_upc'));
              $('.product-actions__buy').css('pointer-events', 'unset');
              // Set UPC on try button.
              $('.product-actions__try').attr('data-selected-shade', currentActiveShade.get('field_shade_upc'));

              // Set selected shade image and shade name.
              const selectedShadeBg = currentActiveShade.get('field_shade_images');
              $('.product-selected-shade .product-shade__shade-img').css('background-image', `url(${selectedShadeBg})`);
              $('.product-shades__selected-text').text(
                currentActiveShade.get("field_shade_id") + " " + currentActiveShade.get("title_1")
              );
            }
            // If no matching carousel shade id exist on page.
            else if (!$('.product-shades__shade-selected').attr('matching')) {
              if (model.get('field_shade_id') || !model.get('field_upc')) {
                $('.product-actions__buy').attr({
                  title : Drupal.t('Please select a shade'),
                  disabled : 'true',
                }).css('pointer-events', 'unset');
              }
              //model.set("is_selected", true);
            }
          }
          // If no shade exists on page set product upc.
          if (collection.length === 1 && model.get('field_shade_upc') === '') {
            // Set buy button att to product upc.
            $('.product-actions__buy').attr('data-selected-shade', model.get('field_upc'));
            $('.product-actions__buy').css('pointer-events', 'unset');

            // Hide product shade wrapper.
            $('.product-shades').remove();
          }
        }

        for (var i = 0; i < localStorage.length; i++) {
          var userNamePro = localStorage.getItem(localStorage.key(0));

          $(".product-finder-user-block .name").text(userNamePro + ",");
        }

        $("#close-productPage").on("click", function () {
          $(this).siblings(".product-finder--popup").addClass("active");
          $("body").addClass("popup--open");
        });

        $(".product-finder-user-block .cancel--button").on(
          "click",
          function () {
            $(".product-finder-user-block .product-finder--popup").removeClass(
              "active"
            );
            $("body").removeClass("popup--open");
          }
        );

        $(".product-finder-user-block #prevButton").on("click", function () {
          history.back();
        });


        // Build the carousel on the left section
        function createCarousel(model, def = '') {
          var imagesData = model.get("carousel_images");
          if (def == 'default') {
            imagesData = model.get("default_images");
          }
          if (imagesData.length) {
            const carouselView = new productApp.views.carousel({
              collection: new Backbone.Collection(imagesData),
            });
            carouselView.render();
            $("." + domClassNames.arrowLeft).addClass(
              domClassNames.productCarouselArrowHide
            );
          }
        }

        // Create all the components for desktop and mobile
        function createComponents(
          shadesData,
          model0,
          productHeaderEl,
          selectedEl,
          shadesListEl,
          actionEl,
          selectedShade,
        ) {
          const detailsViews = new productApp.views.productDetails({
            model: model0,
            el: productHeaderEl,
          });
          detailsViews.render();

          const shadesSelectedView = new productApp.views.productShadeSelected({
            model: model0,
            el: selectedEl,
          });
          shadesSelectedView.render();

          const shadesListView = new productApp.views.productShades({
            collection: shadesData,
            el: shadesListEl,
          });
          shadesListView.render();

          const actionsView = new productApp.views.productActions({
            el: actionEl,
            model: model0,
          });
          actionsView.render();

          const SelectedItemShade = new productApp.views.productSelectedItem({
            el: selectedShade,
            model: model0,
          });
          SelectedItemShade.render();
        }

        // Create an array of carousel images from desktop and mobile images
        function getCarouselImages(productData, defimg = '') {
          var images = productData.field_product_carousel_images;
          if (defimg == 'default') {
            images = productData.field_product_carousel_images_1;
          }
          const desktopImages = images ? images.split(",").map(function (el) {
                  return { img_src: el.trim() };
                })
            : [];
          var mobileimg = productData.field_mobile_image
          if (defimg == 'default') {
            mobileimg = productData.field_mobile_image_1;
          }
          const mobileImages = mobileimg ? mobileimg.split(",").map(function (el) {
                return { img_src: el.trim() };
              })
            : desktopImages;
          const imagesArray = [];
          for (let cntr = 0; cntr < desktopImages.length; cntr++) {
            const imgObj = {};
            imgObj.img_src = desktopImages[cntr].img_src;
            if (mobileImages[cntr] && mobileImages[cntr].img_src) {
              imgObj.mobile_img_src = mobileImages[cntr].img_src;
            } else {
              imgObj.mobile_img_src = desktopImages[cntr].img_src;
            }
            imagesArray.push(imgObj);
          }
          return imagesArray;
        }

        // Toggle next previous and previous arrow button display
        function setNextPrevDisplay(element) {
          $(element).on(
            "beforeChange",
            function (event, slick, currentSlide, nextSlide) {
              // set previous arrow state
              if (nextSlide >= 1) {
                $("." + domClassNames.arrowLeft).show();
              } else {
                $("." + domClassNames.arrowLeft).hide();
              }

              // set next arrow state
              if (nextSlide === slick.slideCount - 1) {
                $("." + domClassNames.arrowRight).hide();
              } else {
                $("." + domClassNames.arrowRight).show();
              }
            }
          );
          $("." + domClassNames.arrowRight).on(
            "click",
            removeLeftArrowInitialClass
          );
          $("." + domClassNames.productCarouselNavButton).on(
            "click",
            removeLeftArrowInitialClass
          );
        }

        // To remove initial hidden class for previous arrow
        function removeLeftArrowInitialClass() {
          $("." + domClassNames.arrowLeft).removeClass(
            domClassNames.productCarouselArrowHide
          );
          $("." + domClassNames.arrowRight).off(
            "click",
            removeLeftArrowInitialClass
          );
          $("." + domClassNames.productCarouselNavButton).off(
            "click",
            removeLeftArrowInitialClass
          );
        }

        // Set slider properties
        function setSider(element) {
          $(element).slick({
            customPaging: customSliderButtons,
            slidesToScroll: 1,
            slidesToShow: 1,
            variableWidth: false,
            appendDots: $(element)
              .parent()
              .find("." + domClassNames.productCarouselNav),
            dots: true,
            arrows: true,
            infinite: false,
            nextArrow: $(element)
              .parent()
              .find("." + domClassNames.arrowRight),
            prevArrow: $(element)
              .parent()
              .find("." + domClassNames.arrowLeft),
          });
          setNextPrevDisplay(element);
        }
        $(document).ready(function () {
          getData();
        });
      });
    },
  };
  Drupal.behaviors.testimonial = {
    attach: function (context, settings) {
      if($('.testimonial-list-carousel-block').length){
        $(".testimonial-list-carousel-block").not('.slick-initialized').slick({
          dots: true,
          arrows: true,
          infinite: false,
          slidesToShow: 2,
          slidesToScroll: 1,
          responsive: [
            {
              breakpoint: 1351,
              settings: {
                arrows: true,
              },
            },
            {
              breakpoint: 768,
              settings: {
                arrows: true,
                centerPadding: "60px",
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
              },
            },
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ],
        });
      }

      if($('.testimonial-list-carousel').length){
        $(".testimonial-list-carousel").not('.slick-initialized').slick({
          dots: true,
          arrows: false,
          infinite: false,
          slidesToShow: 2,
          slidesToScroll: 1,
          responsive: [
            {
              breakpoint: 1351,
              settings: {
                arrows: false,
              },
            },
            {
              breakpoint: 768,
              settings: {
                arrows: false,
                centerPadding: "60px",
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
              },
            },
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ],
        });
      }
      //Testimonial Subtext
      function testimonialSubtextPosition() {
        $('.testimonial-subtext').hide();
        if($('.testimonial-color-wrapper-with-image').length > 0){
          $('.testimonial-subtext').show();
        }
        var text = $('.testimonial-background-color').height();
        $(".testimonial-subtext").css('bottom', text+30);
      }
      testimonialSubtextPosition();
      $(window).on('resize', testimonialSubtextPosition);
    },
  };

  Drupal.behaviors.productSubnavigation = {
    attach: function (context, settings) {
      $("html").css({
        "scroll-behavior": "auto",
      });

      //sub-product bar sticky
      if ($("body").hasClass("toolbar-fixed")) {
        $(".product-sub-navigation").parent("div").parent("div").css({
          position: "sticky",
          top: "40px",
          "z-index": "2",
        });
      } else {
         $(".product-sub-navigation").parent("div").parent("div").addClass('subnavigation-sticky');
         }
      // default select description
      $('.product-sub-navigation ul li').on('click', function () {
        $(this).closest('li').toggleClass('focus').siblings().removeClass('focus');
      });
      $('.product-sub-navigation ul li:first').addClass('focus');

      if ($("body").hasClass("toolbar-fixed")) {
        $(".product-sub-navigation").css({
          top: "10%",
        });
      } else {
        $(".product-sub-navigation").css({
          top: "0",
        });
      }

      var lastId,
        topMenu = jQuery(".product-sub-navigation"),
        topMenuHeight = topMenu.outerHeight() + 1,
        // All list items
        menuItems = topMenu.find("a"),
        // Anchors corresponding to menu items
        scrollItems = menuItems.map(function () {
          var item = jQuery(jQuery(this).attr("href"));
          if (item.length) {
            return item;
          }
        });

      // Bind click handler to menu items
      // so we can get a fancy scroll animation
      menuItems.click(function (e) {
        var href = jQuery(this).attr("href");
          offsetTop =
            href === "#" ? 0 : jQuery(href).offset().top - topMenuHeight + 1;
        jQuery("html, body").stop().animate(
          {
            scrollTop: offsetTop,
          },
          850
        );
        e.preventDefault();
      });
      // Bind to scroll
      jQuery(window).scroll(function () {
        // Get container scroll position
        var fromTop = jQuery(this).scrollTop() + topMenuHeight;
        // Get id of current scroll item
        var cur = scrollItems.map(function () {
          if (jQuery(this).offset().top < fromTop) return this;
        });
        // Get the id of the current element
        cur = cur[cur.length - 1];
        var id = cur && cur.length ? cur[0].id : "";

        if (lastId !== id && (id != "" && id != 'undefined')) {
          lastId = id;
          // Set/remove active class
          menuItems
            .parent()
            .removeClass("is-active")
            .end()
            .filter("[href*=" + id + "]")
            .parent()
            .addClass("is-active");
        }
      });
    },
  };

  Drupal.behaviors.productfaqsection = {
    attach: function (context, settings) {
      jQuery("#faqs .product-faq-section__product-faq:first").addClass(
        "is-active"
      );
      jQuery("#faqs .product-faq-section__product-faq ul li h2").click(
        function () {

          jQuery(this)
            .parents('.product-faq-section__product-faq')
            .toggleClass("is-active")
            .siblings("div")
            .removeClass("is-active");
        }
      );
    },
  };

  Drupal.behaviors.productactionsfixed = {
    attach: function (context, settings) {
      $(window).scroll(function () {
        var scrollPos =
          $(".header-main-navigation").outerHeight() +
          $(".product-details").outerHeight() +
          // fixed value for height of button box in mobile view
          132 -
          window.innerHeight;
        var hasFixed = $(".product-actions-mobile").hasClass(
          "product-actions-mobile--fixed"
        );
        if (!hasFixed) {
          if (window.scrollY >= scrollPos) {
            $(".product-actions-mobile").addClass(
              "product-actions-mobile--fixed"
            );
          }
        } else {
          if (
            hasFixed &&
            window.scrollY <
              scrollPos 
          ) {
            $(".product-actions-mobile").removeClass(
              "product-actions-mobile--fixed"
            );
          }
        }
      });
    },
  };

  Drupal.behaviors.trendingProducts = {
    attach: function (context, settings) {

      once("slider-loaded", ".product-details-trending-slider-container", context).forEach(function (element) {

        const init = {
          autoplay: false,
          infinite: false,
          arrows: false,
          dots: true,
          cssEase: "linear",
          slidesToShow: 3,
          slidesToScroll: 1,
          responsive: [
            {
              breakpoint: 1259,
              settings: {
                arrows: false,
                slidesToShow: 3,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 415,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              },
            },
          ],
        };

        $(() => {
          const win = $(window);
          const slider = $(".product-details-trending-slider");
          win.on("load resize", () => {
            if (win.width() < 1260) {
              slider.not(".slick-initialized").slick(init);
            } else if (slider.hasClass("slick-initialized")) {
              slider.slick("unslick");
            }
          });
        });
      });
    }
  }
})(jQuery, Drupal, once, window._, window.Backbone);
