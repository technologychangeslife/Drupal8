(function ($) {
  /**
   * Product view.
   */
  Drupal.behaviors.product_view = {
    attach: function (context, settings) {
      const inputfilter = $('.js-form-item-term-node-tid-depth input');
      inputfilter.once('changed').change(function () {
        if (this.checked && $(this).attr('child-attr')==='select-all-nested') {
          $(this).parent().parent().parent().siblings('.js-form-item-term-node-tid-depth').find('input').prop('checked', true);
        }
      });

      // How it works page.
      $('#block-exposedformproduct-listingblock-3 .bef-nested ul li .js-form-item-term-node-tid-depth input').change(function (e) {
        if (this.checked && $(this).parent().parent("li").find("ul>ul>li:nth-child(1)").length) {
          e.preventDefault();
          $(this).parent().parent("li").find("ul>ul>li:nth-child(1) input").prop('checked', true).trigger('change');
          $(this).parent().parent("li").find("ul>ul>li:nth-child(1)").addClass('active');
        }
      });
    }
  };

  
 
  // It will load once on page load.
  // Function to select cateory on product finder selection.
  $(document).ready(function () {
    $.urlParameter = function (name) {
      var results = new RegExp("[?&]" + name + "=([^&#]*)").exec(
        window.location.href
      );
      if (results) {
        return results[1] || 0;
      }
    };
    // Check url parameter.
    var message = $.urlParameter("term_node_tid_depth");
    if (message) {
      $(".product-listing-bef-radio .product-list")
        .find("li input:checked")
        .each(function () {
          $(this)
            .parent()
            .parent("li")
            .closest("ul")
            .find("li")
            .removeClass("active");
          $(this).parent().parent("li").addClass("active");
          // For parent selection.
          $(this)
            .parent()
            .parent("li")
            .closest("ul")
            .parent("li")
            .closest("ul")
            .find(">li")
            .removeClass("active");
          $(this)
            .parent()
            .parent("li")
            .closest("ul")
            .parent("li")
            .addClass("active");
        });
    }
  });

})(jQuery);

