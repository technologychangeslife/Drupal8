(function ($, Drupal, once) {
  Drupal.behaviors.productFinder = {
    attach: function (context, settings) {
      const $context = $(context)
      $context
        .find(
          '.product--finder_container .coh-container#product-finder-constant-div',
        )
        .steps({
          headerTag: 'h2',
          bodyTag: 'section',
          transitionEffect: 'fade',
        })
        $context
        .find('.product--finder_container .coh-wysiwyg > .button#prev').addClass('prev-page');
      once('productFinder', 'html', context).forEach(function (element) {
        var selectedList = []
        var productFinder = $('#product-finder-questions') //Product finder div object
        var questionCounter = 0 //Tracks question number
        var previousQuestion = []
        var domain = $(location).attr('host')
        var host = $(location).attr('protocol')
        const langCode = settings.path.currentLanguage;
        $('.campaign-studio-email-component').hide()

        url = (langCode !== 'en') ? `/${langCode}/api/v1/productfinder` : `/api/v1/productfinder`;
        var data = {}
        var ajaxFunc = function (url, data, successFun) {
          $.ajax({
            url: url,
            data: data,
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
            },
            success: successFun,
          })
        }

        ajaxFunc(url, data, intialSuccessFun)

        // First api call.
        function intialSuccessFun(evt) {
          var questions = evt['productFinderFields']['pfData']
          displayNext(questions[0])
        }

        // Create questions on basis of selection.
        function createQuestionElement(questions) {
          var qElement = $('<div>', {
            id: 'question-wrap',
          })

          var header = $('<h3>' + questions.title + '</h3>')
          qElement.append(header)

          var question = $('<p>' + questions.beforeContent + '</p>').append(
            questions.answers,
          )
          qElement.append(question)

          var linkElement = createLink(questions)
          qElement.append(linkElement, questions)

          return qElement
        }

        // Create links.
        function createLink(questions) {
          var linkList = $('<ul>')
          var item

          for (var i = 0; i < questions.answers.length; i++) {
            var type = questions.answers[i].type.replace(/\s+/g, '')

            item = $('<li>')

            // Next link null case.
            if (questions.answers[i].nextLink == null) {
              continue
            }

            link =
              '<a  data-refId = ' +
              questions.refId +
              ' data-type = ' +
              type +
              ' data-id = ' +
              questions.id +
              ' data-nextId=' +
              questions.answers[i].nextLink +
              '>' +
              questions.answers[i].title +
              '</a><span> <img src = ' +
              questions.answers[i].icon +
              '>'

            item.append(link)
            linkList.append(item)
          }
          return linkList
        }

        // Actions on select element.
        $(document).on('click', '#question-wrap ul li a', function (e) {
          var nextId = $(this).attr('data-nextId')
          var id = $(this).attr('data-id')
          var questionType = $(this).attr('data-type')
          var refId = $(this).attr('data-refId')
          if (refId == 'Q1') {
            selectedList = []
          }
          data = {
            nextId: nextId,
            id: id,
            questionType: questionType,
          }
          ajaxFunc(url, data, nextSuccessFun)
        })

        // Ajax sucess function on selection.
        function nextSuccessFun(evt) {
          var questions = evt['productFinderFields']['pfData']

          const filtered = questions.filter((item) => {
            return item.id == data.nextId
          })
          questions = filtered

          questionCounter++
          if (data.questionType == 'NextQuestion') {
            displayNext(questions[0])
            //if (questions[0].refId == 'Q2' || questions[0].refId == ''
            selectedList.push(data.id)
            selectedList.push(data.nextId)

            selectedList = removeDuplicates(selectedList)
          }
          if (
            data.questionType == 'ProductLink' ||
            data.questionType == 'ShadeSelector' ||
            data.questionType == 'CategoryLink'
          ) {
            localStorage.setItem('ProductFinderResultID', data.nextId)
            localStorage.setItem('ProductFinderType', data.questionType)
            $('.campaign-studio-email-component').fadeIn()
            $('#question-wrap').fadeOut()
            $('.product--questions-wrapper').css('display', 'none')

            $('.product--finder_container .coh-wysiwyg > .button#prev').click(
              function () {
                if (
                  $(
                    '.product--questions-wrapper.current .coh-block #prev-question',
                  ).length != 0
                ) {
                  $('.product--questions-wrapper').css('display', 'flex')
                }
              },
            )
          }
        }
        // Remove duplicates.
        function removeDuplicates(arr) {
          return arr.filter((item, index) => arr.indexOf(item) === index)
        }

        // Click handler for the 'prev' button
        $('#prev-question').on('click', function (e) {
          e.preventDefault()
          $('.campaign-studio-email-component').fadeOut()

          if (productFinder.is(':animated')) {
            return false
          }

          ajaxFunc(url, data, prevSuccessFun)
        })
        // Ajax sucess function on previous selection.
        function prevSuccessFun(evt) {
          var questions = evt['productFinderFields']['pfData']
          // Filter selected questions and create array of selected questions.
          for (var i = 0; i < selectedList.length; i++) {
            var values = questions.filter((item) => {
              return item.id == selectedList[i]
            })
            previousQuestion.push(values)
          }

          questionCounter--

          // Show previous Questions.
          displayNext(previousQuestion[questionCounter][0])
        }

        $context
          .find('.coh-component .coh-wysiwyg .button#close')
          .on('click', function () {
            $context.find('body').addClass('popup--open')
            $context.find('.product-finder--popup').addClass('active')
          })

        $context
          .find('.product-finder--popup .cancel--button')
          .on('click', function () {
            $context.find('body').removeClass('popup--open')
            $context.find('.product-finder--popup').removeClass('active')
          })

        $context
          .find('.product--finder_container .coh-wysiwyg + #product-finder-btn')
          .on('click', function () {
            $context
              .find('.product--finder_container .actions li:nth-child(2) a')
              .click()
            $context
              .find('.product--finder_container .coh-wysiwyg > .button#prev')
              .addClass('active')
          })

        if (
          $('.product--finder_container .user-title--trnsition.current')
          .length != 0
        ) {
          setTimeout(function () {
            $context
              .find('.product--finder_container .actions li:nth-child(2) a')
              .click()
          }, 2000)
        }

        $context
          .find('.product-finder--name button#username')
          .on('click', function () {
            var username = $('div#usersname input')
            var regexuser = /^[a-zA-Z\s_0-9]*$/
            if (username.val() && regexuser.test(username.val())) {
              $context
                .find('.product--finder_container .actions li:nth-child(2) a')
                .click()

              if (
                $('.product--finder_container .user-title--trnsition.current')
                .length != 0
              ) {
                setTimeout(function () {
                  $context
                    .find(
                      '.product--finder_container .actions li:nth-child(2) a',
                    )
                    .click()
                }, 1500)
              }
            } else {
              if (!username.siblings().hasClass('username-errormsg')) {
                username.after(
                  '<div class="username-errormsg">Please enter a valid username.',
                )
              }
              username.css('border', '1px solid red')
            }
          })

        $context
          .find('.product--finder_container .product-finder--email .skip-link')
          .on('click', function () {
            $context
              .find('.product--finder_container .actions li:nth-child(2) a')
              .click()
            $context
              .find('.product--finder_container .actions li:nth-child(2) a')
              .click()
            redirectToResult(host, domain)
          })

        var storeName = document.querySelector(
          '.product-finder--name button#username',
        )
        storeName.addEventListener('click', storeIt, false)

        var retriveName = document.querySelector(
          '.product-finder--name button#username',
        )
        retriveName.addEventListener('click', retrieve, false)

        var getUserName = $('.product-finder--name #usersname input')

        function storeIt() {
          localStorage.setItem('productFinderUser', getUserName.val())
        }

        function retrieve() {
          if (!window.localStorage.length) {
            alert('Nothing stored!')
          }
          var userNamePro = localStorage.getItem('productFinderUser')
          $(
            '.product-finder--name.user-title--trnsition #username-display-msg',
          ).text(userNamePro + ',')

          $('.product-finder-user-block .name').text(userNamePro)
        }

        function lastQusetion() {
          $(
            '.product--questions-wrapper.current .coh-block #prev-question',
          ).click()
        }

        $('.product--finder_container .coh-wysiwyg > .button#prev').click(
          function () {
            if (
              $('.product--questions-wrapper.current .coh-block #prev-question')
              .length != 0
            ) {
              lastQusetion()
            } else {
              $('.product--finder_container .actions li:nth-child(1) a').click()
            }
          },
        )

        // Displays next requested element
        function displayNext(questions) {
          productFinder.fadeOut(function () {
            $('#question-wrap').remove()

            var nextQuestion = createQuestionElement(questions)
            productFinder.append(nextQuestion).fadeIn()

            if (selectedList.length > 0) {
              $('.product--questions-wrapper .button').attr(
                'id',
                'prev-question',
              )
              $('#prev-question').show()
            } else if (selectedList.length === 0) {
              $('#prev-question').hide()
              $('.product--questions-wrapper .button').removeAttr('id')
            }
            if (questionCounter === 0) {
              $('#prev-question').hide()
              $('.product--questions-wrapper .button').removeAttr('id')
            }
          })
        }

        // Email form submit.

        $('.product--finder_container #mauticform_rewardsformwebsite').submit(
          function (e) {
            if (
              $(
                '.product--finder_container #mauticform_input_rewardsformwebsite_email',
              ).val() === ''
            ) {
              var errorMsg = Drupal.t('Please enter valid email address')
              $('.product--finder_container .mauticform-error')
                .html(errorMsg)
                .show()
              e.preventDefault()
            } else {
              redirectToResult(host, domain)
            }
          },
        )

        // Redirect to result page.
        function redirectToResult(host, domain) {
          const langCode = drupalSettings.path.currentLanguage;
          if (
            localStorage.getItem('ProductFinderType') == 'ProductLink' ||
            localStorage.getItem('ProductFinderType') == 'ShadeSelector' ||
            localStorage.getItem('ProductFinderType') == 'CategoryLink'
          ) {
            var nodeID = localStorage.getItem('ProductFinderResultID')
            let redirectUrl = (langCode !== 'en') ? `${host}//${domain}/${langCode}/node/${nodeID}?productFinder` : `${host}//${domain}/node/${nodeID}?productFinder`;
            if (localStorage.getItem('ProductFinderType') == 'CategoryLink') {
              redirectUrl = (langCode !== 'en') ? `${host}//${domain}/${langCode}/shop-products/?term_node_tid_depth=?${nodeID}` : `${host}//${domain}/shop-products/?term_node_tid_depth=${nodeID}`;
            }
            $context
              .find('.product--finder_container .actions li:nth-child(2) a')
              .click()
            $context
              .find('.product--finder_container .actions li:nth-child(2) a')
              .click()
            
            setTimeout(function () {
              window.location.href = redirectUrl
            }, 1000)
          }
        }

        $('.product--finder_container .coh-wysiwyg .button').on(
          'click',
          function () {
            if ($('.product-textwith--title').hasClass('current')) {
              $('.product--finder_container .coh-wysiwyg .button').removeClass(
                'active',
              )
            }
          },
        )

        // Added function for Retake Button redirection
        let productParams = new URLSearchParams(window.location.search)
        if (productParams.has('initalquestion')) {
          $context
            .find('.product--finder_container .actions li:nth-child(2) a')
            .click()
          $context
            .find('.product--finder_container .actions li:nth-child(2) a')
            .click()
          $context
            .find('.product--finder_container .actions li:nth-child(2) a')
            .click()
        }

        var enterKeyname = document.getElementById('submit-name')
        var enterKeyemail = document.getElementById(
          'mauticform_input_rewardsformwebsite_email',
        )
        enterKeyname.addEventListener('keypress', function (event) {
          if (event.key === 'Enter') {
            event.preventDefault()
            document.getElementById('username').click()
          }
        })
        enterKeyemail.addEventListener('keypress', function (event) {
          if (event.key === 'Enter') {
            event.preventDefault()
            document
              .getElementById('mauticform_input_rewardsformwebsite_submit')
              .click()
          }
        })
        $(".product--finder_container .coh-wysiwyg .prev-page").click(function(event) {
          if (!$(".product--finder_container .coh-wysiwyg > .button#prev").hasClass("active")) {
            event.preventDefault();
            history.back(1);
          }
        });
      })
    },
  }
})(jQuery, Drupal, once)
