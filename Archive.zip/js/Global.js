class Global {
  createStorage(name, value) {
    localStorage.setItem(name, value);
  }
  getStorage(name) {
    let value = localStorage.getItem(name);
    return value;
  }
  selectCountry() {
    if (this.getStorage("selectedCountry") != null) {
      let country = this.getStorage("selectedCountry");
      let flagIcon = this.getStorage("countryFlag");
      var data = {
        name: country,
        icon: flagIcon,
      };
      return data;
    }
  }
}

export default Global;
