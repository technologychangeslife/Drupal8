(function ($, Drupal, once) {
  Drupal.behaviors.mainMenu = {
    attach: function (context, settings) {
      once("mainMenu", "html", context).forEach(function (element) {
        $(document).ready(function () {
          // Open Tabs.
          function openTabs(evt, categoryName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
              tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
              tablinks[i].className = tablinks[i].className.replace(
                " active",
                ""
              );
            }
            $("." + categoryName).show();

            evt.currentTarget.className += " active";
          }
          let language_code = drupalSettings.path.currentLanguage;
          if (language_code === 'en') {
            $url = '/api/menu_items/main';
          }
          else {
            $url = '/'+ language_code + '/api/menu_items/main';
          }
          // Call Api.
          $.ajax({
            url: $url,
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
            success: function (data, status, xhr) {
              createMenu(data);

              $(".jfm-mainnavigation-tabs .col:first>button").click();
            },
          });

          // CreateMenus.
          let createMenu = function (data) {
            for (var i = 0; i < data.length; i++) {
              let subMenu = data[i].below;
              let menuTitle = data[i].title;
              let attributes = menuTitle = data[i].options;
              if (subMenu) {
                createSubMenu(menuTitle, attributes, subMenu);
              }
            }
          };

          // CreateSubmenus.
          let createSubMenu = function (menuTitle, attributes = null, subMenu) {
            for (const submenus of subMenu) {
              let menu_attribute = attributes.attributes.class[0];
              let subMenuTitle = submenus.title;
              let classes = subMenuTitle.replace(/\s+/g, "");
              let queryParameter = submenus.field_query_parameter;
              let tabs = "";
              //Create Tabs and links.
              if (menu_attribute == "product") {
                let active = "";
                if (submenus.key[0]) {
                  active = "active";
                }
                tabs = `<div class="col"><button class="tablinks ${active}" data-list-target="${queryParameter}" data-category= ${classes}>${submenus.title}</div>`;
              }

              if (menu_attribute == "all-product") {
                let path = submenus.relative;
                path = removeTrailinSlash(path);
                $(".jfm-mainnavigation-view-all").append(
                  "<a href = " + path + ">" + submenus.title + "</a>"
                );
              }

              if (submenus.below) {
                createInnerMenu(classes, submenus.below);
              }

              $(".jfm-mainnavigation-tabs").append(tabs);
            }
          };

          // Create Inner Menus.
          let createInnerMenu = function (classes, innerMenu) {
            for (const innermenus of innerMenu) {
              let innerMenuclasses = innermenus.title.replace(/\s+/g, "");
              let path = innermenus.relative;
              let subMenuDesc = "";
              if (innermenus.description !== null) {
                subMenuDesc = innermenus.description;
              }
              path = removeTrailinSlash(path);

              if (innermenus.options.query !== undefined) {
                let queryOptions = innermenus.options.query.term_node_tid_depth;
                if (queryOptions && queryOptions !== undefined) {
                  path += "?term_node_tid_depth=" + queryOptions;
                }
              }

              if (innermenus.enabled == true) {

                const divEl = $('<div>').addClass('tabcontent ' + classes);
                const ulEL = $("<ul>").addClass(innerMenuclasses);
                const liEL = $("<li>");
                const aEL = $("<a>").attr('href', path).text(innermenus.title);
                const pEL = $("<p>").text(subMenuDesc);

                liEL.append(aEL);
                liEL.append(pEL);

                if (innermenus.below) {
                  liEL.addClass('inner-sub-menu-clickable');
                  const innerMenuLevelEl = createInnerMenuLevel1(innermenus);
                  innerMenuLevelEl && liEL.append(innerMenuLevelEl);
                }

                ulEL.append(liEL);
                divEl.append(ulEL);
                $(".jfm-mainnavigation-links").append(divEl);
              }
            }
          };

          let createInnerMenuLevel1 = function (innermenus) {
            const innerMenu1El = $("<ul>");

            let elCount = 0;

            for (const menuItem of innermenus.below) {
              if (menuItem.enabled == true) {
                elCount++;
                let path = menuItem.relative;
                path = removeTrailinSlash(path);
                const aEL = $("<a>").attr("href", path).text(menuItem.title);
                const pEl = $("<p>").text(menuItem.description);
                const liEl = $('<li>');
                liEl.append(aEL);
                liEl.append(pEl);
                innerMenu1El.append(liEl);
              }
            }
            if (elCount) return innerMenu1El;
          }

          // Open tabs.
          $(document).on(
            "click",
            ".jfm-mainnavigation-tabs .col .tablinks",
            function (e) {
              openTabs(e, $(this).attr("data-category"));
              hideSubMenu();
            }
          );

          $(document).on("click", ".inner-sub-menu-clickable", function (e) {
            const liEl = e.currentTarget;
            const ulEl = $(e.currentTarget).find('ul');
            if (
              e.target.nodeName != "A" &&
              !ulEl.is(e.target) &&
              !ulEl.has(e.target).length
            ) {
              $(".inner-sub-menu-clickable--open")
                .not(e.currentTarget)
                .removeClass("inner-sub-menu-clickable--open");
              $(liEl).toggleClass("inner-sub-menu-clickable--open");
            }
          });

          $(document).on("click", function (e) {
            if (
              !(($(".products-submenu-button").is(e.target) ||
                $(".products-submenu-block").is(e.target)) ||
              ($(".products-submenu-block").has(e.target).length && e.target.nodeName != 'A'))
            ) {
              $(".products-submenu-block").hide(300);
               hideSubMenu();
            }
          });

          $(document).on("click", ".products-submenu-button", function (e) {
            $(".jfm-mainnavigation-tabs .col:first>button").addClass("active");
          });

          $(document).on("click", ".jfm-mainnavigation-view-all>a", function (event) {
            event.preventDefault();
            let eventLink = event.currentTarget.href;

            let queryParameter = null;
            $('.tablinks').each(function(){
              if ($(this).hasClass('active')) {
                queryParameter = $(this).data('list-target');
              }
            });

            if(queryParameter && queryParameter !== undefined) {
              eventLink += queryParameter;
            }

            if (eventLink && eventLink !== undefined) {
              window.location.href = eventLink;
            }
          });

        });
      });

      function removeTrailinSlash(url) {
        return url.replace(/\/+$/, '');
      }

      function hideSubMenu() {
        $(".inner-sub-menu-clickable--open").removeClass(
          "inner-sub-menu-clickable--open"
        );
      }
    },
  };
})(jQuery, Drupal, once);
