(function ($, Drupal) {

  /**
   * Youtube video js.
   */
  Drupal.behaviors.video = {
    attach: function (context, settings) {

      playVideo($('.paragraph--type--how-to-use__video .paragraph--type--how-to-use__play-icon'));
      playVideo($('.views-field-field-video-link .play-icon'));

      function playVideo($video) {
        $video.once('poster').click(function () {
          $(this).hide();
          $(this).siblings('img').hide();
          $(this).siblings('.video-embed-field-responsive-video').show();
          let iframe = $(this).parent().find('iframe');
          let src = iframe.attr('src');
          iframe.attr('allow', 'autoplay');
          iframe.attr('src', src.replace('autoplay=0', 'autoplay=1'));
        })
      }
    }
  }

})(jQuery, Drupal);
